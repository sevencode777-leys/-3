app.post('/save-config', (req, res) => {
  // ...existing code for saving config...
  res.json({ message: "تم بنجاح" });
});