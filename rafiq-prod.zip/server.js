// Enhanced Rafiq Islamic App Server with Authentication
// Complete backend system with email-based authentication

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const i18n = require('i18n');
require('dotenv').config();

const authRoutes = require('./auth');

const app = express();

// i18n config
i18n.configure({
  locales: ['ar', 'en', 'tr'],
  defaultLocale: 'ar',
  directory: __dirname + '/locales',
  objectNotation: true
});

app.use(i18n.init);
app.use(express.json());
app.use(cors());
app.use(helmet());

// Rate limiting
const limiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: 100
});
app.use(limiter);

// MongoDB connection
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB error:', err));

// Auth routes
app.use('/api/auth', authRoutes);

// TODO: Add routes for azkar, ad3eya, ahadith, etc.

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('🛑 SIGTERM received, shutting down gracefully');
    mongoose.connection.close(() => {
        console.log('✅ MongoDB connection closed');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    console.log('🛑 SIGINT received, shutting down gracefully');
    mongoose.connection.close(() => {
        console.log('✅ MongoDB connection closed');
        process.exit(0);
    });
});

module.exports = app;