#!/bin/bash

# Packaging Script for Rafiq Islamic App Distribution
# This script prepares the app for both PWA and APK distribution

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Configuration
APP_NAME="rafiq"
DIST_DIR="dist"
PWA_DIR="$DIST_DIR/pwa"
APK_DIR="$DIST_DIR/apk"
WEB_DIR="$DIST_DIR/web"
BUILD_DATE=$(date +%Y%m%d_%H%M%S)

# Check requirements
check_requirements() {
    log_info "Checking packaging requirements..."

    # Check if Node.js is installed
    if ! command -v node &> /dev/null; then
        log_error "Node.js is not installed. Please install Node.js 16+ first."
        exit 1
    fi

    # Check if npm is installed
    if ! command -v npm &> /dev/null; then
        log_error "npm is not installed. Please install npm first."
        exit 1
    fi

    # Check Node.js version
    NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -lt 16 ]; then
        log_error "Node.js version 16+ is required. Current version: $(node -v)"
        exit 1
    fi

    log_success "All requirements are met"
}

# Create distribution directories
create_directories() {
    log_info "Creating distribution directories..."

    rm -rf "$DIST_DIR"
    mkdir -p "$PWA_DIR"
    mkdir -p "$APK_DIR"
    mkdir -p "$WEB_DIR"

    log_success "Distribution directories created"
}

# Prepare PWA package
prepare_pwa() {
    log_info "Preparing PWA package..."

    # Copy all necessary files for PWA
    cp -r . "$PWA_DIR"

    # Remove unnecessary files for PWA
    rm -rf "$PWA_DIR/android"
    rm -rf "$PWA_DIR/ios"
    rm -rf "$PWA_DIR/node_modules"
    rm -rf "$PWA_DIR/.git"
    rm -f "$PWA_DIR/package-for-distribution.sh"
    rm -f "$PWA_DIR/deploy.sh"

    # Create PWA-optimized files
    create_pwa_optimized_files

    # Generate app icons if not exists
    if [ ! -f "$PWA_DIR/icon-192x192.png" ]; then
        log_warning "App icons not found. Please run icon-generator.html first"
        log_info "Opening icon generator..."
        echo "Please open icon-generator.html in your browser to generate icons"
        read -p "Press Enter after generating icons..."
    fi

    # Update manifest with generated icons
    update_manifest_for_pwa

    # Create PWA installation guide
    create_pwa_guide

    log_success "PWA package prepared"
}

# Create PWA-optimized files
create_pwa_optimized_files() {
    log_info "Creating PWA-optimized files..."

    # Create offline.html for better offline experience
    cat > "$PWA_DIR/offline.html" << 'EOF'
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>رفيق - غير متصل</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
            text-align: center;
            padding: 2rem;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .offline-icon {
            font-size: 4rem;
            margin-bottom: 2rem;
        }

        .offline-message {
            font-size: 1.5rem;
            margin-bottom: 2rem;
        }

        .retry-btn {
            background: white;
            color: #667eea;
            border: none;
            padding: 1rem 2rem;
            border-radius: 25px;
            font-size: 1.1rem;
            cursor: pointer;
            margin: 0.5rem;
        }

        .retry-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <div class="offline-icon">📱</div>
    <div class="offline-message">
        <h1>لا يوجد اتصال بالإنترنت</h1>
        <p>بعض الميزات قد لا تعمل بدون اتصال بالإنترنت</p>
        <p>جاري العمل في وضع الأوفلاين الجزئي...</p>
    </div>
    <button class="retry-btn" onclick="window.location.reload()">إعادة المحاولة</button>
</body>
</html>
EOF

    # Create PWA-specific service worker
    create_optimized_service_worker

    log_success "PWA-optimized files created"
}

# Create optimized service worker for PWA
create_optimized_service_worker() {
    cat > "$PWA_DIR/sw.js" << 'EOF'
// Optimized Service Worker for Rafiq PWA
const CACHE_NAME = 'rafiq-pwa-v2';
const STATIC_CACHE = 'rafiq-static-v2';
const DYNAMIC_CACHE = 'rafiq-dynamic-v2';

const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/style.css',
    '/script.js',
    '/manifest.json',
    '/offline.html'
];

const CACHE_STRATEGIES = {
    '/api/': 'networkFirst',
    '/': 'cacheFirst',
    '/offline.html': 'cacheFirst'
};

self.addEventListener('install', event => {
    console.log('PWA Service Worker: Installing...');
    event.waitUntil(
        caches.open(STATIC_CACHE)
            .then(cache => cache.addAll(STATIC_ASSETS))
            .then(() => self.skipWaiting())
    );
});

self.addEventListener('activate', event => {
    console.log('PWA Service Worker: Activating...');
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
                        return caches.delete(cacheName);
                    }
                })
            );
        }).then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', event => {
    const { request } = event;
    const url = new URL(request.url);

    if (request.method === 'GET') {
        const strategy = CACHE_STRATEGIES[url.pathname] || 'cacheFirst';

        switch (strategy) {
            case 'networkFirst':
                event.respondWith(networkFirstStrategy(request));
                break;
            case 'cacheFirst':
                event.respondWith(cacheFirstStrategy(request));
                break;
            default:
                event.respondWith(cacheFirstStrategy(request));
        }
    }
});

async function networkFirstStrategy(request) {
    try {
        const response = await fetch(request);
        if (response.ok) {
            const cache = await caches.open(DYNAMIC_CACHE);
            cache.put(request, response.clone());
        }
        return response;
    } catch (error) {
        const cachedResponse = await caches.match(request);
        if (cachedResponse) {
            return cachedResponse;
        }
        // Return offline page for navigation requests
        if (request.mode === 'navigate') {
            return caches.match('/offline.html');
        }
        throw error;
    }
}

async function cacheFirstStrategy(request) {
    const cachedResponse = await caches.match(request);
    if (cachedResponse) {
        return cachedResponse;
    }

    try {
        const response = await fetch(request);
        if (response.ok) {
            const cache = await caches.open(STATIC_CACHE);
            cache.put(request, response.clone());
        }
        return response;
    } catch (error) {
        if (request.mode === 'navigate') {
            return caches.match('/offline.html');
        }
        throw error;
    }
}
EOF
}

# Update manifest for PWA
update_manifest_for_pwa() {
    # This would be done by the icon generator
    # For now, we'll use the existing manifest
    log_info "Manifest is already PWA-ready"
}

# Create PWA installation guide
create_pwa_guide() {
    cat > "$PWA_DIR/PWA_INSTALLATION_GUIDE.md" << 'EOF'
# دليل تثبيت تطبيق رفيق كـ PWA

## ما هو PWA؟
PWA (Progressive Web App) هو تطبيق ويب يمكن تثبيته على الهاتف أو الحاسوب ويعمل كالتطبيقات الأصلية.

## طريقة التثبيت

### على Chrome (أندرويد):
1. افتح الموقع في متصفح Chrome
2. اضغط على زر القائمة (ثلاث نقاط)
3. اختر "تثبيت التطبيق" أو "Install App"
4. اتبع التعليمات لإكمال التثبيت

### على Edge (ويندوز):
1. افتح الموقع في متصفح Edge
2. اضغط على زر القائمة (ثلاث نقاط)
3. اختر "التطبيقات" > "تثبيت هذا الموقع كتطبيق"
4. اتبع التعليمات لإكمال التثبيت

### على Safari (iOS):
1. افتح الموقع في متصفح Safari
2. اضغط على زر المشاركة (مربع مع سهم لأعلى)
3. اختر "إضافة إلى الشاشة الرئيسية"
4. اتبع التعليمات لإكمال التثبيت

## مميزات PWA:
- ✅ يعمل بدون إنترنت جزئياً
- ✅ إشعارات ذكية
- ✅ اختصارات على الشاشة الرئيسية
- ✅ تحديثات تلقائية
- ✅ أداء سريع ومحسن

## استكشاف الأخطاء:
- تأكد من استخدام متصفح حديث
- فعل الجافا سكريبت في المتصفح
- اسمح بالإشعارات إذا طُلب منك
- تحقق من اتصال الإنترنت للتثبيت الأولي
EOF
}

# Prepare APK package
prepare_apk() {
    log_info "Preparing APK package..."

    # Check if Capacitor is installed
    if ! npm list -g @capacitor/core &> /dev/null; then
        log_info "Installing Capacitor globally..."
        npm install -g @capacitor/core @capacitor/cli @capacitor/android
    fi

    # Install project dependencies
    if [ -f "package.json" ]; then
        log_info "Installing project dependencies..."
        npm install
    fi

    # Add Android platform if not exists
    if [ ! -d "android" ]; then
        log_info "Adding Android platform..."
        npx cap add android
    else
        log_info "Android platform already exists"
    fi

    # Copy web assets to Android project
    log_info "Syncing web assets to Android project..."
    npx cap sync android

    # Build APK
    log_info "Building APK..."
    npx cap build android

    # Copy APK files to distribution directory
    if [ -d "android/app/build/outputs/apk/release" ]; then
        cp android/app/build/outputs/apk/release/*.apk "$APK_DIR/"
        log_success "APK files copied to $APK_DIR"
    else
        log_warning "APK files not found. Please build manually with Android Studio"
    fi

    # Create APK installation guide
    create_apk_guide

    log_success "APK package prepared"
}

# Create APK installation guide
create_apk_guide() {
    cat > "$APK_DIR/APK_INSTALLATION_GUIDE.md" << 'EOF'
# دليل تثبيت تطبيق رفيق كـ APK

## متطلبات التثبيت:
- هاتف أندرويد (إصدار 7.0 أو أحدث)
- تفعيل "مصادر غير معروفة" في إعدادات الهاتف
- مساحة تخزين كافية (حوالي 10MB)

## طريقة التثبيت:

### الطريقة الأولى: التثبيت المباشر
1. انقل ملف APK إلى هاتفك
2. افتح مدير الملفات على الهاتف
3. اضغط على ملف APK
4. اسمح بالتثبيت من مصادر غير معروفة إذا طُلب
5. اتبع تعليمات المثبت

### الطريقة الثانية: ADB (للمطورين)
```bash
# تأكد من تفعيل USB Debugging على الهاتف
adb install rafiq.apk

# أو للنسخة التجريبية
adb install -r rafiq.apk
```

### الطريقة الثالثة: Android Studio
1. افتح Android Studio
2. اذهب إلى Device Manager
3. اختر هاتفك أو أنشئ محاكي
4. شغل التطبيق من Android Studio

## استكشاف الأخطاء:

### مشكلة: "التطبيق لم يثبت"
- تأكد من تفعيل "مصادر غير معروفة"
- تحقق من مساحة التخزين المتاحة
- جرب إعادة تشغيل الهاتف

### مشكلة: "خطأ في التحليل"
- تأكد من سلامة ملف APK
- جرب تحميل الملف مرة أخرى
- تحقق من إصدار أندرويد (7.0+ مطلوب)

### مشكلة: "التطبيق يتعطل"
- أعد تشغيل الهاتف
- مسح بيانات التطبيق من الإعدادات
- إعادة تثبيت التطبيق

## النشر على Google Play Store:

### متطلبات النشر:
1. اشتراك Google Play Developer (25 دولار سنوياً)
2. توقيع التطبيق بمفتاح خاص
3. إعداد معلومات التطبيق والمتجر

### خطوات النشر:
1. سجل في Google Play Console
2. أنشئ تطبيق جديد
3. ارفع ملف APK أو Bundle
4. أضف لقطات الشاشة والوصف
5. حدد سعر التطبيق (مجاني أو مدفوع)
6. أرسل للمراجعة (يستغرق عدة أيام)

## التواصل:
لأي مشاكل في التثبيت أو الاستخدام، تواصل معنا:
- البريد الإلكتروني: support@sevencodes.com
- تويتر: @seven_code7
EOF
}

# Prepare web package
prepare_web() {
    log_info "Preparing web package..."

    # Copy files for web distribution
    cp -r . "$WEB_DIR"

    # Remove development files
    rm -rf "$WEB_DIR/android"
    rm -rf "$WEB_DIR/ios"
    rm -rf "$WEB_DIR/node_modules"
    rm -rf "$WEB_DIR/.git"
    rm -f "$WEB_DIR/package-for-distribution.sh"
    rm -f "$WEB_DIR/deploy.sh"

    # Create web hosting guide
    create_web_guide

    log_success "Web package prepared"
}

# Create web hosting guide
create_web_guide() {
    cat > "$WEB_DIR/WEB_HOSTING_GUIDE.md" << 'EOF'
# دليل استضافة تطبيق رفيق على الويب

## خيارات الاستضافة:

### 1. Netlify (موصى به - مجاني)
```bash
# 1. ارفع المشروع إلى GitHub
# 2. اذهب إلى netlify.com
# 3. اختر "Add new site" > "Import an existing project"
# 4. اربط مستودع GitHub
# 5. سيقوم Netlify بالنشر تلقائياً
# 6. الموقع سيكون متاحاً على: https://your-site.netlify.app
```

### 2. Vercel (مجاني وسريع)
```bash
# 1. ارفع المشروع إلى GitHub
# 2. اذهب إلى vercel.com
# 3. اختر "Import Project"
# 4. اربط مستودع GitHub
# 5. سيقوم Vercel بالنشر تلقائياً
# 6. الموقع سيكون متاحاً على: https://your-project.vercel.app
```

### 3. خادم تقليدي (Apache/Nginx)
```bash
# 1. ارفع الملفات إلى خادمك
# 2. استخدم إعدادات .htaccess أو nginx.conf
# 3. فعل HTTPS باستخدام Let's Encrypt
# 4. الموقع سيكون متاحاً على نطاقك الخاص
```

## إعدادات الخادم:

### Apache (.htaccess موجود):
- انسخ ملف .htaccess إلى المجلد الجذر
- فعل mod_rewrite و mod_headers
- فعل HTTPS وشهادة SSL

### Nginx (nginx.conf موجود):
- انسخ إعدادات nginx.conf
- فعل gzip compression
- فعل HTTPS وشهادة SSL

### Docker (Dockerfile موجود):
```bash
# بناء الحاوية
docker build -t rafiq-app .

# تشغيل الحاوية
docker run -d -p 80:80 rafiq-app
```

## متطلبات الاستضافة:
- ✅ دعم HTTPS (مطلوب لـ PWA)
- ✅ دعم Service Workers
- ✅ مساحة تخزين 10MB+
- ✅ نطاق ترددي مناسب
- ✅ دعم الضغط (gzip)

## استكشاف الأخطاء:

### مشكلة: "لا يمكن تثبيت PWA"
- تأكد من HTTPS (غير HTTP)
- فحص Service Worker في وحدة التحكم
- تحقق من إعدادات Content Security Policy

### مشكلة: "التطبيق بطيء"
- فعل الضغط gzip
- استخدم CDN للملفات الثابتة
- فعل التخزين المؤقت للمتصفح

### مشكلة: "خطأ في API"
- تحقق من CORS settings
- فعل الرؤوس المطلوبة
- فحص إعدادات الخادم

## مراقبة الأداء:
- استخدم Google PageSpeed Insights
- راقب Core Web Vitals
- تابع استخدام الذاكرة والشبكة
- استخدم أدوات مراقبة مثل Sentry

## الدعم:
لأي مشاكل في الاستضافة، تواصل معنا:
- البريد الإلكتروني: support@sevencodes.com
- التوثيق التقني: TECHNICAL_DOCS.md
EOF
}

# Create distribution archives
create_archives() {
    log_info "Creating distribution archives..."

    # Create PWA archive
    cd "$PWA_DIR"
    tar -czf "../rafiq-pwa-$BUILD_DATE.tar.gz" .
    cd - > /dev/null

    # Create web archive
    cd "$WEB_DIR"
    tar -czf "../rafiq-web-$BUILD_DATE.tar.gz" .
    cd - > /dev/null

    # Create APK archive (if APK exists)
    if [ -f "$APK_DIR/*.apk" ]; then
        cd "$APK_DIR"
        tar -czf "../rafiq-apk-$BUILD_DATE.tar.gz" .
        cd - > /dev/null
    fi

    # Create complete distribution archive
    tar -czf "$DIST_DIR/rafiq-complete-$BUILD_DATE.tar.gz" . --exclude="$DIST_DIR"

    log_success "Distribution archives created"
}

# Generate checksums
generate_checksums() {
    log_info "Generating checksums..."

    find "$DIST_DIR" -name "*.tar.gz" -exec sha256sum {} \; > "$DIST_DIR/checksums.sha256"
    find "$DIST_DIR" -name "*.apk" -exec sha256sum {} \; >> "$DIST_DIR/checksums.sha256"

    log_success "Checksums generated"
}

# Create distribution summary
create_summary() {
    log_info "Creating distribution summary..."

    cat > "$DIST_DIR/README.md" << EOF
# تطبيق رفيق - حزمة التوزيع

## تاريخ الإنشاء: $(date)
## الإصدار: 2.0.0
## رقم البناء: $BUILD_DATE

## محتويات الحزمة:

### 📱 PWA (Progressive Web App)
- **الموقع**: متاح في جميع المتصفحات الحديثة
- **الميزات**: يعمل بدون إنترنت جزئياً، إشعارات ذكية، تثبيت على الشاشة الرئيسية
- **الحجم**: ~2MB
- **الملف**: rafiq-pwa-$BUILD_DATE.tar.gz

### 🌐 الويب التقليدي
- **الاستضافة**: يعمل على أي خادم ويب
- **الميزات**: جميع ميزات التطبيق بدون PWA
- **الحجم**: ~2MB
- **الملف**: rafiq-web-$BUILD_DATE.tar.gz

### 📱 APK للأندرويد
- **المنصة**: أندرويد 7.0+
- **الميزات**: تطبيق أصلي للأندرويد
- **الحجم**: ~5MB
- **الملف**: rafiq-apk-$BUILD_DATE.tar.gz (إذا كان متاحاً)

## تعليمات التثبيت:

### للـ PWA:
1. ارفع ملف rafiq-pwa-$BUILD_DATE.tar.gz إلى خادمك
2. فك الضغط في المجلد الجذر
3. فعل HTTPS للحصول على جميع ميزات PWA
4. افتح الموقع في متصفح حديث وقم بتثبيت التطبيق

### للـ APK:
1. انقل ملف APK إلى هاتف أندرويد
2. فعل "مصادر غير معروفة" في الإعدادات
3. اضغط على الملف واتبع تعليمات التثبيت

### للويب التقليدي:
1. ارفع ملف rafiq-web-$BUILD_DATE.tar.gz إلى خادمك
2. فك الضغط في المجلد الجذر
3. الموقع جاهز للاستخدام

## التحقق من سلامة الملفات:
استخدم ملف checksums.sha256 للتحقق من سلامة التحميل:
\`\`\`bash
sha256sum -c checksums.sha256
\`\`\`

## الدعم:
لأي مشاكل في التثبيت أو الاستخدام:
- البريد الإلكتروني: support@sevencodes.com
- التوثيق: اقرأ USER_GUIDE.md و TECHNICAL_DOCS.md

## الترخيص:
تطبيق رفيق مرخص تحت رخصة MIT للكود المصدري والمحتوى الإسلامي حر ومتاح للجميع.

---
**استوديو seven_code7**
**المطورون: ليث ومحمود**
EOF

    log_success "Distribution summary created"
}

# Main packaging flow
main() {
    log_info "Starting packaging process for Rafiq Islamic App..."

    check_requirements
    create_directories
    prepare_pwa
    prepare_apk
    prepare_web
    create_archives
    generate_checksums
    create_summary

    log_success "Packaging completed successfully!"
    log_info "Distribution files are available in: $DIST_DIR/"
    log_info ""
    log_info "📱 PWA Package: $DIST_DIR/rafiq-pwa-$BUILD_DATE.tar.gz"
    log_info "🌐 Web Package: $DIST_DIR/rafiq-web-$BUILD_DATE.tar.gz"
    log_info "📱 APK Package: $DIST_DIR/rafiq-apk-$BUILD_DATE.tar.gz (if available)"
    log_info "📋 Complete Package: $DIST_DIR/rafiq-complete-$BUILD_DATE.tar.gz"
    log_info ""
    log_info "📖 Read $DIST_DIR/README.md for installation instructions"
}

# Handle script arguments
case "${1:-}" in
    "pwa")
        check_requirements
        create_directories
        prepare_pwa
        ;;
    "apk")
        check_requirements
        prepare_apk
        ;;
    "web")
        check_requirements
        create_directories
        prepare_web
        ;;
    "all")
        main
        ;;
    "help"|"-h"|"--help")
        echo "Usage: $0 [target]"
        echo "Targets:"
        echo "  pwa      - Package for PWA distribution only"
        echo "  apk      - Package for APK distribution only"
        echo "  web      - Package for web distribution only"
        echo "  all      - Package for all distribution methods (default)"
        echo ""
        echo "Examples:"
        echo "  $0 all       # Package everything"
        echo "  $0 pwa       # PWA only"
        echo "  $0 apk       # APK only"
        ;;
    *)
        log_warning "No target specified, packaging everything..."
        main
        ;;
esac