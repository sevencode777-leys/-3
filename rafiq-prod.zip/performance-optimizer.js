// Performance Optimization and Security Enhancements for Rafiq Islamic App

class PerformanceOptimizer {
    constructor() {
        this.optimizationStats = {
            imagesOptimized: 0,
            cacheHits: 0,
            bundleSize: 0,
            loadTime: 0
        };

        this.init();
    }

    init() {
        this.setupLazyLoading();
        this.optimizeImages();
        this.preloadCriticalResources();
        this.setupResourceHints();
        this.implementCodeSplitting();
        this.setupCompression();
        this.monitorPerformance();
        this.setupSecurityHeaders();
        this.optimizeMemoryUsage();
    }

    // Lazy Loading Implementation
    setupLazyLoading() {
        if ('IntersectionObserver' in window) {
            const lazyImages = document.querySelectorAll('img[data-src]');
            const imageObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        imageObserver.unobserve(img);
                        this.optimizationStats.imagesOptimized++;
                    }
                });
            });

            lazyImages.forEach(img => imageObserver.observe(img));
        }
    }

    // Image Optimization
    optimizeImages() {
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            // Add loading attribute for native lazy loading
            if (!img.hasAttribute('loading')) {
                img.setAttribute('loading', 'lazy');
            }

            // Optimize image quality based on device pixel ratio
            if (img.src && window.devicePixelRatio > 1) {
                this.optimizeHighDPIImage(img);
            }

            // Add error handling
            img.addEventListener('error', () => {
                this.handleImageError(img);
            });
        });
    }

    optimizeHighDPIImage(img) {
        if (img.src.includes('.png') || img.src.includes('.jpg')) {
            // In a real implementation, you'd serve WebP or AVIF formats
            // For now, we'll add optimization parameters
            const optimizedSrc = img.src + '?optimized=true';
            img.src = optimizedSrc;
        }
    }

    handleImageError(img) {
        // Fallback to a default Islamic-themed image or icon
        img.src = 'data:image/svg+xml;base64,' + btoa(`
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
                <text y=".9em" font-size="90" text-anchor="middle">🕌</text>
            </svg>
        `);
        img.alt = 'صورة إسلامية';
    }

    // Critical Resource Preloading
    preloadCriticalResources() {
        const criticalResources = [
            { href: 'style.css', as: 'style' },
            { href: 'script.js', as: 'script' },
            { href: 'hadiths.json', as: 'fetch' },
            { href: 'adhkar.json', as: 'fetch' },
            { href: 'duas.json', as: 'fetch' }
        ];

        criticalResources.forEach(resource => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.href = resource.href;
            link.as = resource.as;
            link.crossOrigin = 'anonymous';
            document.head.appendChild(link);
        });
    }

    // Resource Hints
    setupResourceHints() {
        // DNS prefetch for external APIs
        const dnsPrefetch = [
            'api.quran.com',
            'api.aladhan.com',
            'cdn.islamic.network',
            'fonts.googleapis.com'
        ];

        dnsPrefetch.forEach(domain => {
            const link = document.createElement('link');
            link.rel = 'dns-prefetch';
            link.href = `//${domain}`;
            document.head.appendChild(link);
        });

        // Preconnect to critical origins
        const preconnect = [
            'https://api.quran.com',
            'https://api.aladhan.com'
        ];

        preconnect.forEach(origin => {
            const link = document.createElement('link');
            link.rel = 'preconnect';
            link.href = origin;
            link.crossOrigin = 'anonymous';
            document.head.appendChild(link);
        });
    }

    // Code Splitting Implementation
    implementCodeSplitting() {
        // Split large functions into chunks
        this.splitQuranFunctions();
        this.splitHadithFunctions();
        this.splitAIFunctions();
    }

    splitQuranFunctions() {
        // Quran-related functions can be loaded on demand
        window.loadQuranModule = () => {
            return import('./quran-module.js');
        };
    }

    splitHadithFunctions() {
        // Hadith-related functions can be loaded on demand
        window.loadHadithModule = () => {
            return import('./hadith-module.js');
        };
    }

    splitAIFunctions() {
        // AI functions can be loaded on demand
        window.loadAIModule = () => {
            return import('./ai-module.js');
        };
    }

    // Compression Setup
    setupCompression() {
        // Enable gzip compression detection
        if ('compression' in window) {
            // Modern browsers support compression negotiation
            console.log('Compression supported');
        }

        // Setup response compression for API calls
        this.setupAPICompression();
    }

    setupAPICompression() {
        // Original fetch wrapper with compression
        const originalFetch = window.fetch;
        window.fetch = function(...args) {
            const [url, options = {}] = args;

            // Add compression headers
            options.headers = {
                ...options.headers,
                'Accept-Encoding': 'gzip, deflate, br',
                'Cache-Control': 'no-cache'
            };

            return originalFetch.apply(this, [url, options]);
        };
    }

    // Performance Monitoring
    monitorPerformance() {
        // Monitor Core Web Vitals
        this.monitorCoreWebVitals();

        // Monitor resource loading
        this.monitorResourceLoading();

        // Monitor memory usage
        this.monitorMemoryUsage();

        // Monitor network performance
        this.monitorNetworkPerformance();
    }

    monitorCoreWebVitals() {
        // First Contentful Paint (FCP)
        new PerformanceObserver((list) => {
            for (const entry of list.getEntries()) {
                if (entry.name === 'first-contentful-paint') {
                    console.log('FCP:', entry.startTime);
                    this.logPerformanceMetric('fcp', entry.startTime);
                }
            }
        }).observe({ entryTypes: ['paint'] });

        // Largest Contentful Paint (LCP)
        new PerformanceObserver((list) => {
            for (const entry of list.getEntries()) {
                console.log('LCP:', entry.startTime);
                this.logPerformanceMetric('lcp', entry.startTime);
            }
        }).observe({ entryTypes: ['largest-contentful-paint'] });

        // Cumulative Layout Shift (CLS)
        new PerformanceObserver((list) => {
            for (const entry of list.getEntries()) {
                if (!entry.hadRecentInput) {
                    console.log('CLS:', entry.value);
                    this.logPerformanceMetric('cls', entry.value);
                }
            }
        }).observe({ entryTypes: ['layout-shift'] });
    }

    monitorResourceLoading() {
        new PerformanceObserver((list) => {
            for (const entry of list.getEntries()) {
                if (entry.duration > 1000) { // Resources taking more than 1s
                    console.warn('Slow resource:', entry.name, entry.duration);
                }
            }
        }).observe({ entryTypes: ['resource'] });
    }

    monitorMemoryUsage() {
        if ('memory' in performance) {
            setInterval(() => {
                const memory = performance.memory;
                const usage = {
                    used: Math.round(memory.usedJSHeapSize / 1048576),
                    total: Math.round(memory.totalJSHeapSize / 1048576),
                    limit: Math.round(memory.jsHeapSizeLimit / 1048576)
                };

                if (usage.used > 50) { // More than 50MB
                    this.triggerGarbageCollection();
                }

                this.logPerformanceMetric('memory', usage);
            }, 30000); // Check every 30 seconds
        }
    }

    monitorNetworkPerformance() {
        if ('connection' in navigator) {
            const connection = navigator.connection;

            // Monitor connection changes
            connection.addEventListener('change', () => {
                this.adaptToConnectionQuality(connection);
            });

            // Initial adaptation
            this.adaptToConnectionQuality(connection);
        }
    }

    adaptToConnectionQuality(connection) {
        const quality = connection.effectiveType;

        switch (quality) {
            case 'slow-2g':
            case '2g':
                this.enableLowBandwidthMode();
                break;
            case '3g':
                this.enableMediumBandwidthMode();
                break;
            case '4g':
            default:
                this.enableHighBandwidthMode();
                break;
        }
    }

    enableLowBandwidthMode() {
        document.body.classList.add('low-bandwidth');
        // Disable animations, reduce image quality, etc.
        this.reduceResourceQuality();
    }

    enableMediumBandwidthMode() {
        document.body.classList.remove('low-bandwidth');
        document.body.classList.add('medium-bandwidth');
    }

    enableHighBandwidthMode() {
        document.body.classList.remove('low-bandwidth', 'medium-bandwidth');
    }

    reduceResourceQuality() {
        // Reduce image quality for slow connections
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            if (img.src) {
                img.style.imageRendering = 'optimizeSpeed';
            }
        });
    }

    triggerGarbageCollection() {
        if (window.gc) {
            window.gc();
        } else {
            // Force cleanup by removing unused elements
            this.cleanupUnusedElements();
        }
    }

    cleanupUnusedElements() {
        // Remove elements that are not in viewport
        const elements = document.querySelectorAll('.hidden, .off-screen');
        elements.forEach(el => {
            if (!this.isElementInViewport(el)) {
                el.remove();
            }
        });
    }

    isElementInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    // Security Enhancements
    setupSecurityHeaders() {
        // Content Security Policy
        this.setupCSP();

        // XSS Protection
        this.preventXSS();

        // Secure cookie handling
        this.setupSecureCookies();

        // HTTPS enforcement
        this.enforceHTTPS();
    }

    setupCSP() {
        const cspHeader = `
            default-src 'self';
            script-src 'self' 'unsafe-inline' 'unsafe-eval' https://api.quran.com https://api.aladhan.com;
            style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
            img-src 'self' data: https: blob:;
            font-src 'self' https://fonts.gstatic.com;
            connect-src 'self' https://api.quran.com https://api.aladhan.com https://cdn.islamic.network;
            manifest-src 'self';
            worker-src 'self';
        `.replace(/\s+/g, ' ').trim();

        // Note: In a real deployment, this would be set via server headers
        console.log('CSP Header:', cspHeader);
    }

    preventXSS() {
        // Sanitize user inputs
        this.sanitizeInputs();

        // Escape HTML in dynamic content
        this.escapeDynamicContent();
    }

    sanitizeInputs() {
        const inputs = document.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            input.addEventListener('input', (e) => {
                e.target.value = this.sanitizeString(e.target.value);
            });
        });
    }

    sanitizeString(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    escapeDynamicContent() {
        // Ensure dynamic content is properly escaped
        const dynamicElements = document.querySelectorAll('[data-dynamic]');
        dynamicElements.forEach(el => {
            if (el.innerHTML) {
                el.innerHTML = this.sanitizeString(el.innerHTML);
            }
        });
    }

    setupSecureCookies() {
        // Ensure cookies are secure
        document.cookie.split(';').forEach(cookie => {
            const [name] = cookie.split('=');
            if (name.trim()) {
                // In a real implementation, set secure flags on the server
                console.log(`Cookie ${name} should be marked as Secure and HttpOnly`);
            }
        });
    }

    enforceHTTPS() {
        if (location.protocol !== 'https:' && location.hostname !== 'localhost') {
            location.replace(`https:${location.href.substring(location.protocol.length)}`);
        }
    }

    // Memory Optimization
    optimizeMemoryUsage() {
        // Setup memory management
        this.setupMemoryManagement();

        // Cleanup event listeners
        this.cleanupEventListeners();

        // Optimize DOM operations
        this.optimizeDOMOperations();
    }

    setupMemoryManagement() {
        // Monitor and cleanup memory periodically
        setInterval(() => {
            if (this.shouldTriggerCleanup()) {
                this.performMemoryCleanup();
            }
        }, 60000); // Every minute
    }

    shouldTriggerCleanup() {
        if ('memory' in performance) {
            const memory = performance.memory;
            const usageRatio = memory.usedJSHeapSize / memory.jsHeapSizeLimit;
            return usageRatio > 0.8; // More than 80% memory usage
        }
        return false;
    }

    performMemoryCleanup() {
        // Clear unused caches
        this.clearUnusedCaches();

        // Remove detached DOM nodes
        this.removeDetachedNodes();

        // Clear large data structures if not needed
        this.clearUnnecessaryData();
    }

    clearUnusedCaches() {
        if ('caches' in window) {
            caches.keys().then(names => {
                names.forEach(name => {
                    if (this.isOldCache(name)) {
                        caches.delete(name);
                    }
                });
            });
        }
    }

    isOldCache(cacheName) {
        const age = Date.now() - (this.cacheTimestamps[cacheName] || 0);
        return age > 24 * 60 * 60 * 1000; // Older than 24 hours
    }

    removeDetachedNodes() {
        // Use WeakMap to track detached nodes
        if (this.detachedNodes) {
            this.detachedNodes.forEach(node => {
                if (node && !document.body.contains(node)) {
                    node.remove();
                }
            });
        }
    }

    clearUnnecessaryData() {
        // Clear search history if too large
        const searchHistory = JSON.parse(localStorage.getItem('searchHistory') || '[]');
        if (searchHistory.length > 100) {
            localStorage.setItem('searchHistory', JSON.stringify(searchHistory.slice(0, 50)));
        }

        // Clear old chat history
        const chatHistory = JSON.parse(localStorage.getItem('chatHistory') || '[]');
        if (chatHistory.length > 200) {
            localStorage.setItem('chatHistory', JSON.stringify(chatHistory.slice(-100)));
        }
    }

    // Utility Functions
    logPerformanceMetric(name, value) {
        // Log to console for debugging
        console.log(`Performance Metric - ${name}:`, value);

        // In a real app, send to analytics service
        if (window.gtag) {
            gtag('event', 'performance_metric', {
                metric_name: name,
                metric_value: value,
                custom_parameter: 'rafiq_app'
            });
        }
    }

    getOptimizationStats() {
        return {
            ...this.optimizationStats,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            url: window.location.href
        };
    }
}

// Initialize performance optimizer when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.performanceOptimizer = new PerformanceOptimizer();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PerformanceOptimizer;
}