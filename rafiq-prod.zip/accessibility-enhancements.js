// Accessibility Enhancements for Rafiq Islamic App
// This script adds comprehensive accessibility features and ARIA support

class AccessibilityManager {
    constructor() {
        this.screenReaderEnabled = false;
        this.highContrastMode = false;
        this.largeTextMode = false;
        this.reducedMotionMode = false;

        this.init();
    }

    init() {
        this.detectScreenReader();
        this.setupAccessibilityFeatures();
        this.enhanceKeyboardNavigation();
        this.addARIALabels();
        this.setupFocusManagement();
        this.createAccessibilityToolbar();
        this.setupLiveRegions();
        this.enhanceFormAccessibility();
        this.setupColorContrast();
        this.setupMotionPreferences();
        this.addSkipLinks();
        this.setupScreenReaderAnnouncements();
    }

    // Screen Reader Detection
    detectScreenReader() {
        // Detect common screen readers
        const screenReaderPatterns = [
            /NVDA/i,
            /JAWS/i,
            /VoiceOver/i,
            /TalkBack/i,
            /Orca/i,
            /Dragon/i
        ];

        const userAgent = navigator.userAgent;
        this.screenReaderEnabled = screenReaderPatterns.some(pattern => pattern.test(userAgent));

        // Also check for Windows high contrast mode
        if (window.matchMedia && window.matchMedia('(prefers-contrast: high)').matches) {
            this.highContrastMode = true;
        }

        // Check for reduced motion preference
        if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            this.reducedMotionMode = true;
        }
    }

    // Setup Accessibility Features
    setupAccessibilityFeatures() {
        // Add accessibility CSS class to body
        if (this.screenReaderEnabled) {
            document.body.classList.add('screen-reader-active');
        }

        if (this.highContrastMode) {
            document.body.classList.add('high-contrast');
        }

        if (this.reducedMotionMode) {
            document.body.classList.add('reduced-motion');
        }

        // Listen for preference changes
        if (window.matchMedia) {
            window.matchMedia('(prefers-contrast: high)').addEventListener('change', (e) => {
                this.highContrastMode = e.matches;
                this.updateContrastMode();
            });

            window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', (e) => {
                this.reducedMotionMode = e.matches;
                this.updateMotionMode();
            });
        }
    }

    updateContrastMode() {
        if (this.highContrastMode) {
            document.body.classList.add('high-contrast');
            this.enhanceColorContrast();
        } else {
            document.body.classList.remove('high-contrast');
        }
    }

    updateMotionMode() {
        if (this.reducedMotionMode) {
            document.body.classList.add('reduced-motion');
            this.reduceAnimations();
        } else {
            document.body.classList.remove('reduced-motion');
        }
    }

    // Enhance Color Contrast
    enhanceColorContrast() {
        const style = document.createElement('style');
        style.id = 'high-contrast-styles';
        style.textContent = `
            .high-contrast {
                --primary-color: #000000 !important;
                --secondary-color: #000000 !important;
                --text-color: #000000 !important;
                --background-color: #ffffff !important;
                --border-color: #000000 !important;
            }

            .high-contrast * {
                border-color: #000000 !important;
                color: #000000 !important;
                background: #ffffff !important;
            }

            .high-contrast button {
                border: 2px solid #000000 !important;
                background: #ffffff !important;
                color: #000000 !important;
            }

            .high-contrast .section {
                border: 2px solid #000000 !important;
            }
        `;
        document.head.appendChild(style);
    }

    reduceAnimations() {
        const style = document.createElement('style');
        style.id = 'reduced-motion-styles';
        style.textContent = `
            .reduced-motion *,
            .reduced-motion *::before,
            .reduced-motion *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
                scroll-behavior: auto !important;
            }
        `;
        document.head.appendChild(style);
    }

    // Enhanced Keyboard Navigation
    enhanceKeyboardNavigation() {
        // Add keyboard shortcuts
        this.setupKeyboardShortcuts();

        // Improve focus visibility
        this.enhanceFocusVisibility();

        // Setup keyboard trap for modals
        this.setupModalKeyboardTrap();
    }

    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Alt + number keys for quick navigation
            if (e.altKey && !e.ctrlKey && !e.shiftKey) {
                const shortcuts = {
                    '1': 'prayer',
                    '2': 'quran',
                    '3': 'calendar',
                    '4': 'hadith',
                    '5': 'dhikr',
                    '6': 'dua',
                    '7': 'qibla',
                    '8': 'tasbih',
                    '9': 'ai',
                    '0': 'settings'
                };

                const sectionId = shortcuts[e.key];
                if (sectionId) {
                    e.preventDefault();
                    this.navigateToSection(sectionId);
                    this.announceToScreenReader(`انتقلت إلى قسم ${this.getSectionName(sectionId)}`);
                }
            }

            // Escape key to close modals
            if (e.key === 'Escape') {
                this.closeAllModals();
            }

            // Space bar to play/pause audio
            if (e.key === ' ' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
                if (window.audioPlayer && !audioPlayer.paused) {
                    e.preventDefault();
                    this.toggleAudio();
                }
            }
        });
    }

    navigateToSection(sectionId) {
        // Remove active class from all sections
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });

        // Add active class to target section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');

            // Update navigation buttons
            document.querySelectorAll('nav button').forEach(button => {
                button.classList.remove('active');
            });

            // Find and activate corresponding nav button
            const navButton = document.querySelector(`nav button[onclick="showSection('${sectionId}')"]`);
            if (navButton) {
                navButton.classList.add('active');
            }

            // Focus first focusable element in section
            const firstFocusable = targetSection.querySelector('button, input, select, textarea, [tabindex="0"]');
            if (firstFocusable) {
                firstFocusable.focus();
            }
        }
    }

    getSectionName(sectionId) {
        const names = {
            'prayer': 'أوقات الصلاة',
            'quran': 'القرآن الكريم',
            'calendar': 'التقويم الهجري',
            'hadith': 'الأحاديث',
            'dhikr': 'الأذكار',
            'dua': 'الأدعية',
            'qibla': 'القبلة',
            'tasbih': 'المسبحة',
            'ai': 'الذكاء الاصطناعي',
            'settings': 'الإعدادات'
        };
        return names[sectionId] || sectionId;
    }

    enhanceFocusVisibility() {
        const style = document.createElement('style');
        style.textContent = `
            .focus-visible,
            *:focus-visible {
                outline: 3px solid var(--primary-color) !important;
                outline-offset: 2px !important;
                border-radius: 4px !important;
            }

            .screen-reader-active *:focus {
                outline: 3px solid #0066cc !important;
                outline-offset: 2px !important;
            }
        `;
        document.head.appendChild(style);
    }

    setupModalKeyboardTrap() {
        // Ensure modal dialogs trap keyboard focus
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                const modal = document.querySelector('.modal');
                if (modal) {
                    this.trapFocusInModal(e, modal);
                }
            }
        });
    }

    trapFocusInModal(event, modal) {
        const focusableElements = modal.querySelectorAll(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );

        const firstFocusable = focusableElements[0];
        const lastFocusable = focusableElements[focusableElements.length - 1];

        if (event.shiftKey) {
            if (document.activeElement === firstFocusable) {
                event.preventDefault();
                lastFocusable.focus();
            }
        } else {
            if (document.activeElement === lastFocusable) {
                event.preventDefault();
                firstFocusable.focus();
            }
        }
    }

    // ARIA Labels and Roles
    addARIALabels() {
        // Add ARIA labels to main sections
        const sections = document.querySelectorAll('.section');
        sections.forEach(section => {
            const heading = section.querySelector('h2');
            if (heading) {
                section.setAttribute('aria-labelledby', `heading-${section.id}`);
                heading.id = `heading-${section.id}`;
            }
        });

        // Add ARIA labels to navigation
        const navButtons = document.querySelectorAll('nav button');
        navButtons.forEach((button, index) => {
            button.setAttribute('aria-describedby', `nav-desc-${index}`);
            const description = document.createElement('span');
            description.id = `nav-desc-${index}`;
            description.className = 'sr-only';
            description.textContent = `اضغط للانتقال إلى ${button.textContent}`;
            button.appendChild(description);
        });

        // Add ARIA labels to prayer times
        const prayerTimes = document.querySelectorAll('#prayer-times p');
        prayerTimes.forEach(prayer => {
            const prayerName = prayer.textContent.split(':')[0];
            prayer.setAttribute('aria-label', `وقت صلاة ${prayerName}`);
        });

        // Add ARIA labels to Quran verses
        this.enhanceQuranAccessibility();

        // Add ARIA labels to form controls
        this.enhanceFormAccessibility();

        // Add ARIA live regions for dynamic content
        this.setupLiveRegions();
    }

    enhanceQuranAccessibility() {
        const verses = document.querySelectorAll('.verse');
        verses.forEach((verse, index) => {
            verse.setAttribute('role', 'article');
            verse.setAttribute('aria-label', `آية ${index + 1}`);

            const verseNumber = verse.querySelector('.verse-number');
            if (verseNumber) {
                verseNumber.setAttribute('aria-label', `رقم الآية ${verseNumber.textContent}`);
            }
        });

        // Add ARIA labels to audio controls
        const audioControls = document.querySelectorAll('#audio-controls button');
        audioControls.forEach(button => {
            const label = button.textContent;
            button.setAttribute('aria-label', label);
        });
    }

    enhanceFormAccessibility() {
        // Add labels to inputs without labels
        const inputs = document.querySelectorAll('input:not([aria-label]):not([aria-labelledby])');
        inputs.forEach(input => {
            if (!input.labels || input.labels.length === 0) {
                const placeholder = input.placeholder || input.id || 'input';
                input.setAttribute('aria-label', placeholder);
            }
        });

        // Add required field indicators
        const requiredInputs = document.querySelectorAll('input[required]');
        requiredInputs.forEach(input => {
            input.setAttribute('aria-required', 'true');
            const label = document.querySelector(`label[for="${input.id}"]`);
            if (label && !label.textContent.includes('*')) {
                label.innerHTML += ' <span aria-label="حقل مطلوب">*</span>';
            }
        });
    }

    // Focus Management
    setupFocusManagement() {
        // Track focus for better UX
        let lastFocusedElement = null;

        document.addEventListener('focusin', (e) => {
            lastFocusedElement = e.target;
        });

        // Restore focus when needed
        window.restoreLastFocus = () => {
            if (lastFocusedElement) {
                lastFocusedElement.focus();
            }
        };

        // Focus first element when section changes
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    const target = mutation.target;
                    if (target.classList.contains('section') && target.classList.contains('active')) {
                        this.focusFirstElement(target);
                    }
                }
            });
        });

        document.querySelectorAll('.section').forEach(section => {
            observer.observe(section, { attributes: true });
        });
    }

    focusFirstElement(section) {
        const firstFocusable = section.querySelector(
            'button, input, select, textarea, [tabindex="0"]:not([tabindex="-1"])'
        );

        if (firstFocusable) {
            setTimeout(() => {
                firstFocusable.focus();
            }, 100);
        }
    }

    // Accessibility Toolbar
    createAccessibilityToolbar() {
        const toolbar = document.createElement('div');
        toolbar.id = 'accessibility-toolbar';
        toolbar.className = 'accessibility-toolbar';
        toolbar.setAttribute('role', 'toolbar');
        toolbar.setAttribute('aria-label', 'أدوات إمكانية الوصول');

        toolbar.innerHTML = `
            <button id="toggle-screen-reader" aria-pressed="false" title="وضع قارئ الشاشة">
                <span class="icon">📱</span>
                <span class="label">قارئ الشاشة</span>
            </button>
            <button id="toggle-high-contrast" aria-pressed="false" title="وضع التباين العالي">
                <span class="icon">🎨</span>
                <span class="label">تباين عالي</span>
            </button>
            <button id="toggle-large-text" aria-pressed="false" title="نص كبير">
                <span class="icon">🔤</span>
                <span class="label">نص كبير</span>
            </button>
            <button id="toggle-reduced-motion" aria-pressed="false" title="تقليل الحركة">
                <span class="icon">⚡</span>
                <span class="label">تقليل الحركة</span>
            </button>
            <button id="keyboard-shortcuts" title="اختصارات لوحة المفاتيح">
                <span class="icon">⌨️</span>
                <span class="label">الاختصارات</span>
            </button>
        `;

        // Add styles
        const style = document.createElement('style');
        style.textContent = `
            .accessibility-toolbar {
                position: fixed;
                top: 50%;
                right: 20px;
                transform: translateY(-50%);
                background: var(--card-background);
                border: 2px solid var(--primary-color);
                border-radius: 10px;
                padding: 1rem;
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
                z-index: 1000;
                box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            }

            .accessibility-toolbar button {
                background: var(--button-background);
                color: white;
                border: none;
                padding: 0.5rem;
                border-radius: 5px;
                cursor: pointer;
                display: flex;
                align-items: center;
                gap: 0.25rem;
                font-size: 0.8rem;
                transition: all 0.3s ease;
            }

            .accessibility-toolbar button:hover,
            .accessibility-toolbar button[aria-pressed="true"] {
                background: var(--primary-color);
                transform: scale(1.05);
            }

            .accessibility-toolbar .icon {
                font-size: 1rem;
            }

            .accessibility-toolbar .label {
                font-size: 0.7rem;
                white-space: nowrap;
            }

            @media (max-width: 768px) {
                .accessibility-toolbar {
                    position: fixed;
                    top: auto;
                    bottom: 20px;
                    right: 20px;
                    transform: none;
                    flex-direction: row;
                    padding: 0.5rem;
                }

                .accessibility-toolbar .label {
                    display: none;
                }
            }
        `;
        document.head.appendChild(style);

        document.body.appendChild(toolbar);

        // Add event listeners
        document.getElementById('toggle-screen-reader').addEventListener('click', () => {
            this.toggleScreenReaderMode();
        });

        document.getElementById('toggle-high-contrast').addEventListener('click', () => {
            this.toggleHighContrastMode();
        });

        document.getElementById('toggle-large-text').addEventListener('click', () => {
            this.toggleLargeTextMode();
        });

        document.getElementById('toggle-reduced-motion').addEventListener('click', () => {
            this.toggleReducedMotionMode();
        });

        document.getElementById('keyboard-shortcuts').addEventListener('click', () => {
            this.showKeyboardShortcuts();
        });
    }

    toggleScreenReaderMode() {
        this.screenReaderEnabled = !this.screenReaderEnabled;
        const button = document.getElementById('toggle-screen-reader');

        if (this.screenReaderEnabled) {
            document.body.classList.add('screen-reader-active');
            button.setAttribute('aria-pressed', 'true');
            this.announceToScreenReader('تم تفعيل وضع قارئ الشاشة');
        } else {
            document.body.classList.remove('screen-reader-active');
            button.setAttribute('aria-pressed', 'false');
            this.announceToScreenReader('تم تعطيل وضع قارئ الشاشة');
        }
    }

    toggleHighContrastMode() {
        this.highContrastMode = !this.highContrastMode;
        const button = document.getElementById('toggle-high-contrast');

        if (this.highContrastMode) {
            document.body.classList.add('high-contrast');
            button.setAttribute('aria-pressed', 'true');
            this.enhanceColorContrast();
            this.announceToScreenReader('تم تفعيل وضع التباين العالي');
        } else {
            document.body.classList.remove('high-contrast');
            button.setAttribute('aria-pressed', 'false');
            document.getElementById('high-contrast-styles')?.remove();
            this.announceToScreenReader('تم تعطيل وضع التباين العالي');
        }
    }

    toggleLargeTextMode() {
        this.largeTextMode = !this.largeTextMode;
        const button = document.getElementById('toggle-large-text');

        if (this.largeTextMode) {
            document.body.classList.add('large-text');
            button.setAttribute('aria-pressed', 'true');
            this.enhanceTextSize();
            this.announceToScreenReader('تم تفعيل وضع النص الكبير');
        } else {
            document.body.classList.remove('large-text');
            button.setAttribute('aria-pressed', 'false');
            this.resetTextSize();
            this.announceToScreenReader('تم تعطيل وضع النص الكبير');
        }
    }

    toggleReducedMotionMode() {
        this.reducedMotionMode = !this.reducedMotionMode;
        const button = document.getElementById('toggle-reduced-motion');

        if (this.reducedMotionMode) {
            document.body.classList.add('reduced-motion');
            button.setAttribute('aria-pressed', 'true');
            this.reduceAnimations();
            this.announceToScreenReader('تم تفعيل وضع تقليل الحركة');
        } else {
            document.body.classList.remove('reduced-motion');
            button.setAttribute('aria-pressed', 'false');
            document.getElementById('reduced-motion-styles')?.remove();
            this.announceToScreenReader('تم تعطيل وضع تقليل الحركة');
        }
    }

    enhanceTextSize() {
        const style = document.createElement('style');
        style.id = 'large-text-styles';
        style.textContent = `
            .large-text {
                font-size: 120% !important;
            }

            .large-text .section h2 {
                font-size: 2.4rem !important;
            }

            .large-text .verse-text {
                font-size: 1.56rem !important;
            }

            .large-text #tasbih-counter {
                font-size: 3.6rem !important;
            }
        `;
        document.head.appendChild(style);
    }

    resetTextSize() {
        document.getElementById('large-text-styles')?.remove();
    }

    showKeyboardShortcuts() {
        const shortcuts = [
            { keys: 'Alt + 1', description: 'الانتقال لأوقات الصلاة' },
            { keys: 'Alt + 2', description: 'الانتقال للقرآن الكريم' },
            { keys: 'Alt + 3', description: 'الانتقال للتقويم الهجري' },
            { keys: 'Alt + 4', description: 'الانتقال للأحاديث' },
            { keys: 'Alt + 5', description: 'الانتقال للأذكار' },
            { keys: 'Alt + 6', description: 'الانتقال للأدعية' },
            { keys: 'Alt + 7', description: 'الانتقال للقبلة' },
            { keys: 'Alt + 8', description: 'الانتقال للمسبحة' },
            { keys: 'Alt + 9', description: 'الانتقال للذكاء الاصطناعي' },
            { keys: 'Alt + 0', description: 'الانتقال للإعدادات' },
            { keys: 'Escape', description: 'إغلاق النافذة الحالية' },
            { keys: 'Tab', description: 'التنقل بين العناصر' },
            { keys: 'مسافة', description: 'تشغيل/إيقاف الصوت' }
        ];

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content" role="dialog" aria-labelledby="shortcuts-title" aria-modal="true">
                <span class="close" onclick="this.closest('.modal').remove()" aria-label="إغلاق">&times;</span>
                <h2 id="shortcuts-title">اختصارات لوحة المفاتيح</h2>
                <div class="shortcuts-list">
                    ${shortcuts.map(shortcut => `
                        <div class="shortcut-item">
                            <kbd class="shortcut-keys">${shortcut.keys}</kbd>
                            <span class="shortcut-description">${shortcut.description}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;

        // Add styles for shortcuts modal
        const style = document.createElement('style');
        style.textContent = `
            .shortcuts-list {
                display: grid;
                gap: 1rem;
                margin-top: 1rem;
            }

            .shortcut-item {
                display: flex;
                align-items: center;
                gap: 1rem;
                padding: 0.5rem;
                background: var(--input-background);
                border-radius: 5px;
            }

            .shortcut-keys {
                background: var(--primary-color);
                color: white;
                padding: 0.25rem 0.5rem;
                border-radius: 3px;
                font-family: monospace;
                font-size: 0.9rem;
                min-width: 80px;
                text-align: center;
            }

            .shortcut-description {
                color: var(--text-color);
            }
        `;
        document.head.appendChild(style);

        document.body.appendChild(modal);
        this.announceToScreenReader('عرض اختصارات لوحة المفاتيح');
    }

    // Live Regions for Screen Reader Announcements
    setupLiveRegions() {
        // Create live region for announcements
        const liveRegion = document.createElement('div');
        liveRegion.id = 'live-region';
        liveRegion.setAttribute('aria-live', 'polite');
        liveRegion.setAttribute('aria-atomic', 'true');
        liveRegion.className = 'sr-only';
        document.body.appendChild(liveRegion);

        // Create assertive live region for urgent announcements
        const assertiveRegion = document.createElement('div');
        assertiveRegion.id = 'assertive-live-region';
        assertiveRegion.setAttribute('aria-live', 'assertive');
        assertiveRegion.setAttribute('aria-atomic', 'true');
        assertiveRegion.className = 'sr-only';
        document.body.appendChild(assertiveRegion);
    }

    announceToScreenReader(message, assertive = false) {
        const regionId = assertive ? 'assertive-live-region' : 'live-region';
        const region = document.getElementById(regionId);

        if (region) {
            region.textContent = message;

            // Clear after announcement
            setTimeout(() => {
                region.textContent = '';
            }, 1000);
        }
    }

    // Skip Links
    addSkipLinks() {
        const skipLinks = document.createElement('div');
        skipLinks.className = 'skip-links';
        skipLinks.innerHTML = `
            <a href="#main-content" class="skip-link">تخطي إلى المحتوى الرئيسي</a>
            <a href="#prayer" class="skip-link">تخطي إلى أوقات الصلاة</a>
            <a href="#quran" class="skip-link">تخطي إلى القرآن الكريم</a>
            <a href="#calendar" class="skip-link">تخطي إلى التقويم</a>
            <a href="#hadith" class="skip-link">تخطي إلى الأحاديث</a>
        `;

        // Add styles for skip links
        const style = document.createElement('style');
        style.textContent = `
            .skip-links {
                position: absolute;
                top: -40px;
                left: 6px;
                display: flex;
                gap: 0.5rem;
                z-index: 1000;
            }

            .skip-link {
                background: var(--primary-color);
                color: white;
                padding: 0.5rem 1rem;
                text-decoration: none;
                border-radius: 5px;
                font-size: 0.9rem;
                transition: top 0.3s ease;
            }

            .skip-link:focus {
                top: 6px;
            }

            .sr-only {
                position: absolute;
                width: 1px;
                height: 1px;
                padding: 0;
                margin: -1px;
                overflow: hidden;
                clip: rect(0, 0, 0, 0);
                white-space: nowrap;
                border: 0;
            }
        `;
        document.head.appendChild(style);

        document.body.insertBefore(skipLinks, document.body.firstChild);

        // Add main content ID
        const mainElement = document.querySelector('main');
        if (mainElement) {
            mainElement.id = 'main-content';
        }
    }

    // Screen Reader Announcements
    setupScreenReaderAnnouncements() {
        // Announce prayer time changes
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList' || mutation.type === 'characterData') {
                    const countdownElement = document.getElementById('countdown');
                    if (countdownElement && countdownElement.textContent.includes('باقي على')) {
                        this.announceToScreenReader(countdownElement.textContent, true);
                    }
                }
            });
        });

        const countdownElement = document.getElementById('countdown');
        if (countdownElement) {
            observer.observe(countdownElement, {
                childList: true,
                characterData: true,
                subtree: true
            });
        }

        // Announce section changes
        const sectionObserver = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    const section = mutation.target;
                    if (section.classList.contains('active')) {
                        const heading = section.querySelector('h2');
                        if (heading) {
                            this.announceToScreenReader(`انتقلت إلى ${heading.textContent}`);
                        }
                    }
                }
            });
        });

        document.querySelectorAll('.section').forEach(section => {
            sectionObserver.observe(section, { attributes: true });
        });
    }

    // Modal Management
    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.remove();
        });
        this.announceToScreenReader('تم إغلاق جميع النوافذ');
    }

    toggleAudio() {
        if (window.audioPlayer) {
            if (audioPlayer.paused) {
                audioPlayer.play();
                this.announceToScreenReader('تشغيل الصوت');
            } else {
                audioPlayer.pause();
                this.announceToScreenReader('إيقاف الصوت');
            }
        }
    }
}

// Initialize accessibility manager when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.accessibilityManager = new AccessibilityManager();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AccessibilityManager;
}