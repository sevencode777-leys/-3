const CACHE_NAME = 'rafiq-cache-v2';
const DYNAMIC_CACHE = 'rafiq-dynamic-v2';
const STATIC_CACHE = 'rafiq-static-v2';

// Files to cache immediately
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/style.css',
    '/script.js',
    '/manifest.json',
    '/sw.js'
];

// Files to cache on demand
const CACHE_ON_DEMAND = [
    '/hadiths.json',
    '/adhkar.json',
    '/duas.json'
];

// API endpoints to cache
const API_CACHE_PATTERNS = [
    'api.quran.com',
    'api.aladhan.com',
    'cdn.islamic.network'
];

self.addEventListener('install', event => {
    console.log('Service Worker: Installing...');
    event.waitUntil(
        caches.open(STATIC_CACHE)
            .then(cache => {
                console.log('Service Worker: Caching static assets');
                return cache.addAll(STATIC_ASSETS);
            })
            .then(() => {
                return caches.open(DYNAMIC_CACHE);
            })
            .then(() => {
                console.log('Service Worker: Installation complete');
                return self.skipWaiting();
            })
    );
});

self.addEventListener('activate', event => {
    console.log('Service Worker: Activating...');
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
                        console.log('Service Worker: Deleting old cache', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        }).then(() => {
            console.log('Service Worker: Activation complete');
            return self.clients.claim();
        })
    );
});

self.addEventListener('fetch', event => {
    const { request } = event;
    const url = new URL(request.url);

    // Handle different types of requests
    if (request.method === 'GET') {
        if (isStaticAsset(request)) {
            event.respondWith(handleStaticAssetRequest(request));
        } else if (isAPIRequest(request)) {
            event.respondWith(handleAPIRequest(request));
        } else if (isQuranAudioRequest(request)) {
            event.respondWith(handleQuranAudioRequest(request));
        } else {
            event.respondWith(handleGenericRequest(request));
        }
    }
});

function isStaticAsset(request) {
    return request.url.includes('.css') ||
           request.url.includes('.js') ||
           request.url.includes('.html') ||
           request.url.includes('manifest.json');
}

function isAPIRequest(request) {
    return API_CACHE_PATTERNS.some(pattern => request.url.includes(pattern));
}

function isQuranAudioRequest(request) {
    return request.url.includes('cdn.islamic.network') &&
           request.url.includes('.mp3');
}

function handleStaticAssetRequest(request) {
    return caches.match(request)
        .then(response => {
            if (response) {
                return response;
            }
            return fetch(request)
                .then(response => {
                    // Don't cache if not a valid response
                    if (!response || response.status !== 200) {
                        return response;
                    }

                    const responseToCache = response.clone();
                    caches.open(STATIC_CACHE)
                        .then(cache => cache.put(request, responseToCache));

                    return response;
                });
        });
}

function handleAPIRequest(request) {
    return fetch(request)
        .then(response => {
            // Don't cache if not a valid response
            if (!response || response.status !== 200) {
                return response;
            }

            const responseToCache = response.clone();
            caches.open(DYNAMIC_CACHE)
                .then(cache => cache.put(request, responseToCache));

            return response;
        })
        .catch(() => {
            // Return cached version if available
            return caches.match(request);
        });
}

function handleQuranAudioRequest(request) {
    return caches.match(request)
        .then(response => {
            if (response) {
                return response;
            }

            return fetch(request)
                .then(response => {
                    if (response && response.status === 200) {
                        const responseToCache = response.clone();
                        caches.open(DYNAMIC_CACHE)
                            .then(cache => cache.put(request, responseToCache));
                    }
                    return response;
                });
        });
}

function handleGenericRequest(request) {
    return caches.match(request)
        .then(response => {
            if (response) {
                return response;
            }
            return fetch(request);
        });
}

// Handle background sync for offline actions
self.addEventListener('sync', event => {
    if (event.tag === 'background-sync') {
        event.waitUntil(doBackgroundSync());
    }
});

function doBackgroundSync() {
    // Sync offline actions when connection is restored
    return new Promise((resolve) => {
        console.log('Service Worker: Background sync triggered');
        // Here you would handle offline actions like saving bookmarks, etc.
        resolve();
    });
}

// Handle push notifications
self.addEventListener('push', event => {
    if (event.data) {
        const data = event.data.json();
        const options = {
            body: data.body,
            icon: '/icon-192x192.png',
            badge: '/badge-72x72.png',
            vibrate: [200, 100, 200],
            data: data,
            actions: [
                {
                    action: 'open',
                    title: 'فتح التطبيق'
                },
                {
                    action: 'close',
                    title: 'إغلاق'
                }
            ]
        };

        event.waitUntil(
            self.registration.showNotification(data.title, options)
        );
    }
});

// Handle notification clicks
self.addEventListener('notificationclick', event => {
    event.notification.close();

    if (event.action === 'open') {
        event.waitUntil(
            clients.openWindow('/')
        );
    }
});