# التوثيق التقني - تطبيق رفيق 🕌

## نظرة عامة تقنية

تطبيق رفيق هو تطبيق ويب تقدمي (PWA) مبني بتقنيات الويب الحديثة مع دعم كامل للتحويل إلى تطبيقات الهواتف الذكية.

## التقنيات المستخدمة

### التقنيات الأساسية
- **HTML5** - بناء الهيكل والمحتوى
- **CSS3** - التصميم والتفاعلات البصرية
- **Vanilla JavaScript** - المنطق والتفاعلات (بدون إطارات عمل ثقيلة)
- **PHP** - الخادم البسيط للإعدادات والملفات الثابتة

### تقنيات متقدمة
- **Progressive Web App (PWA)** - التطبيق كتطبيق أصلي
- **Service Workers** - العمل بدون إنترنت والتخزين المؤقت
- **Web APIs** - Geolocation, Notifications, Local Storage, IndexedDB
- **Capacitor** - تحويل إلى تطبيقات أصلية (Android/iOS)

## بنية المشروع

```
rafiq/
├── index.html              # الملف الرئيسي
├── style.css              # التصميم والأنماط
├── script.js              # منطق التطبيق الرئيسي
├── sw.js                  # Service Worker للـ PWA
├── manifest.json          # إعدادات PWA
├── capacitor.config.json  # إعدادات Capacitor
├── performance-optimizer.js # مُحسن الأداء
├── security-config.json   # إعدادات الأمان
├── test-suite.html        # اختبارات شاملة
├── USER_GUIDE.md         # دليل المستخدم
├── TECHNICAL_DOCS.md     # هذا الملف
├── hadiths.json          # قاعدة بيانات الأحاديث
├── adhkar.json           # الأذكار والأدعية
├── duas.json             # الأدعية المتنوعة
└── server.php            # خادم PHP البسيط (اختياري)
```

## API المستخدمة

### APIs خارجية
```javascript
// أوقات الصلاة
https://api.aladhan.com/v1/timings?latitude=${lat}&longitude=${lng}&method=2

// القرآن الكريم
https://api.quran.com/api/v4/chapters
https://api.quran.com/api/v4/verses/by_chapter/${chapterId}
https://api.quran.com/api/v4/search?q=${query}

// التاريخ الهجري
https://api.aladhan.com/v1/gToH

// التلاوة الصوتية
https://cdn.islamic.network/quran/audio/128/${reciter}/${chapterId}${verseNumber}.mp3
```

## الميزات التقنية

### 1. إدارة الحالة (State Management)
```javascript
// استخدام Local Storage للحفظ الدائم
const appState = {
    theme: localStorage.getItem('theme') || 'light',
    language: localStorage.getItem('language') || 'ar',
    settings: JSON.parse(localStorage.getItem('appSettings')) || {},
    bookmarks: JSON.parse(localStorage.getItem('bookmarks')) || [],
    prayerStats: JSON.parse(localStorage.getItem('prayerStats')) || {}
};
```

### 2. نظام التخزين المؤقت الذكي
```javascript
// Service Worker للتخزين المؤقت
const CACHE_NAME = 'rafiq-cache-v2';
const STATIC_ASSETS = ['/', '/index.html', '/style.css', '/script.js'];
const API_CACHE_PATTERNS = ['api.quran.com', 'api.aladhan.com'];
```

### 3. نظام الإشعارات الذكية
```javascript
// إشعارات محلية مع جدولة ذكية
function schedulePrayerNotifications() {
    // حساب وقت التذكير قبل كل صلاة
    // استخدام Notification API
    // دعم الصوت والاهتزاز
}
```

### 4. نظام البحث المتقدم
```javascript
// بحث في القرآن والأحاديث
function performAdvancedSearch(query, data) {
    // تقييم الصلة والأهمية
    // دعم البحث بالمعاني والنص
    // ترتيب النتائج حسب الدقة
}
```

### 5. نظام الذكاء الاصطناعي البسيط
```javascript
// قاعدة معرفة إسلامية محلية
const aiKnowledgeBase = {
    'ما هي أركان الإسلام؟': 'أركان الإسلام خمسة...',
    'كيف أتعلم الصلاة؟': 'الصلاة تؤدى بالوضوء أولاً...'
};

function getAIResponse(message) {
    // مطابقة الأنماط
    // ردود سياقية
    // تعلم من التفاعلات
}
```

## الأمان والخصوصية

### 1. Content Security Policy (CSP)
```json
{
  "contentSecurityPolicy": {
    "directives": {
      "defaultSrc": ["'self'"],
      "scriptSrc": ["'self'", "https://api.quran.com"],
      "styleSrc": ["'self'", "https://fonts.googleapis.com"],
      "imgSrc": ["'self'", "data:", "https:"],
      "connectSrc": ["'self'", "https://api.quran.com"]
    }
  }
}
```

### 2. تشفير البيانات
```javascript
// تشفير النسخ الاحتياطية
function encryptData(data) {
    // استخدام AES-256-GCM
    // مفتاح آمن للتشفير
    // ضغط البيانات قبل التشفير
}
```

### 3. التحقق من صحة البيانات
```javascript
// تنظيف المدخلات
function sanitizeInput(input) {
    // إزالة العناصر الضارة
    // التحقق من الحد الأقصى للطول
    // منع XSS attacks
}
```

## الأداء والتحسين

### 1. تحسين الأداء
```javascript
// Lazy Loading للصور
const imageObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.dataset.src;
        }
    });
});

// Code Splitting
window.loadQuranModule = () => import('./quran-module.js');
window.loadHadithModule = () => import('./hadith-module.js');
```

### 2. مراقبة الأداء
```javascript
// Core Web Vitals
new PerformanceObserver((list) => {
    for (const entry of list.getEntries()) {
        console.log('FCP:', entry.startTime);
        console.log('LCP:', entry.startTime);
        console.log('CLS:', entry.value);
    }
}).observe({ entryTypes: ['paint', 'largest-contentful-paint', 'layout-shift'] });
```

### 3. تحسين الذاكرة
```javascript
// مراقبة استخدام الذاكرة
if ('memory' in performance) {
    setInterval(() => {
        const memory = performance.memory;
        if (memory.usedJSHeapSize > 50 * 1024 * 1024) { // 50MB
            this.triggerGarbageCollection();
        }
    }, 30000);
}
```

## الاختبار والجودة

### 1. اختبارات تلقائية
```javascript
// اختبار شامل لجميع الوظائف
async function runAllTests() {
    const tests = [
        testBrowserCompatibility(),
        testServiceWorker(),
        testLocalStorage(),
        testNotifications(),
        testGeolocation(),
        testPrayerAPI(),
        testQuranAPI(),
        // ... المزيد من الاختبارات
    ];

    for (const test of tests) {
        await runTest(test);
    }
}
```

### 2. اختبارات الأداء
```javascript
// قياس سرعة التحميل
window.addEventListener('load', () => {
    setTimeout(() => {
        const perfData = performance.getEntriesByType('navigation')[0];
        const loadTime = perfData.loadEventEnd - perfData.loadEventStart;
        console.log('Load Time:', loadTime);
    }, 0);
});
```

## النشر والتوزيع

### 1. كـ PWA
```bash
# خدمة التطبيق محلياً
python -m http.server 8000

# أو استخدام أي خادم ويب
# nginx, Apache, etc.
```

### 2. كـ تطبيق أندرويد
```bash
# تثبيت Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# إضافة المنصة
npx cap add android

# بناء التطبيق
npx cap build android

# تشغيل على الهاتف
npx cap run android
```

### 3. كـ تطبيق iOS
```bash
# إضافة المنصة
npx cap add ios

# بناء التطبيق
npx cap build ios

# تشغيل على الهاتف
npx cap run ios
```

## الصيانة والتطوير

### 1. إضافة ميزات جديدة
```javascript
// نمط الوحدات المستقلة
class NewFeature {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadData();
        this.bindUI();
    }
}
```

### 2. تحديث قواعد البيانات
```javascript
// تحديث الأحاديث والأذكار
async function updateIslamicContent() {
    try {
        const response = await fetch('https://api.example.com/islamic-content');
        const newContent = await response.json();
        await saveToLocalStorage('islamicContent', newContent);
    } catch (error) {
        console.error('فشل في تحديث المحتوى:', error);
    }
}
```

### 3. مراقبة الأخطاء
```javascript
// نظام تسجيل الأخطاء الشامل
window.addEventListener('error', (event) => {
    logError({
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        error: event.error,
        timestamp: new Date().toISOString()
    });
});
```

## استكشاف الأخطاء وإصلاحها

### مشاكل شائعة وحلولها

#### 1. مشكلة في Service Worker
```javascript
// فحص حالة Service Worker
navigator.serviceWorker.getRegistration().then(registration => {
    if (registration) {
        console.log('Service Worker مُسجل:', registration.scope);
    } else {
        console.log('Service Worker غير مُسجل');
    }
});
```

#### 2. مشكلة في التخزين المحلي
```javascript
// فحص سعة التخزين
function checkStorageQuota() {
    if ('storage' in navigator && 'estimate' in navigator.storage) {
        navigator.storage.estimate().then(estimate => {
            console.log('Storage Usage:', estimate.usage, 'of', estimate.quota);
        });
    }
}
```

#### 3. مشكلة في الـ APIs الخارجية
```javascript
// فحص حالة الـ API
async function checkAPIHealth() {
    const apis = [
        'https://api.aladhan.com/v1/timings?latitude=21.4225&longitude=39.8262',
        'https://api.quran.com/api/v4/chapters/1'
    ];

    for (const api of apis) {
        try {
            const response = await fetch(api);
            console.log(`${api}: ${response.ok ? 'OK' : 'ERROR'}`);
        } catch (error) {
            console.log(`${api}: OFFLINE`);
        }
    }
}
```

## النسخ الاحتياطي والاستعادة

### 1. النسخ الاحتياطي التلقائي
```javascript
// إعدادات النسخ الاحتياطي
const backupSettings = {
    autoBackup: true,
    frequency: 'weekly', // daily, weekly, monthly
    encryptBackup: true,
    maxBackupSize: 10 * 1024 * 1024, // 10MB
    retentionDays: 30
};
```

### 2. تشفير البيانات
```javascript
// تشفير قوي للبيانات الحساسة
async function encryptSensitiveData(data, password) {
    const algorithm = { name: 'AES-GCM', length: 256 };
    const key = await crypto.subtle.generateKey(algorithm, true, ['encrypt', 'decrypt']);
    const iv = crypto.getRandomValues(new Uint8Array(16));

    const encodedData = new TextEncoder().encode(JSON.stringify(data));
    const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, encodedData);

    return { encrypted, iv, key };
}
```

## التحديثات المستقبلية

### خطة التطوير
1. **الإصدار 2.1** - إضافة ميزات جديدة
   - دعم المصاحف المختلفة
   - تلاوات صوتية إضافية
   - تفسير أكثر تفصيلاً

2. **الإصدار 2.2** - تحسينات تقنية
   - تطبيق للهواتف الذكية
   - مزامنة سحابية
   - ذكاء اصطناعي متقدم

3. **الإصدار 3.0** - ثورة في التجربة
   - واجهة ثلاثية الأبعاد
   - تفاعل صوتي متقدم
   - دعم الواقع المعزز

## المساهمة في التطوير

### كيفية المساهمة
1. **الإبلاغ عن الأخطاء** - استخدم نظام تتبع المشاكل
2. **اقتراح ميزات جديدة** - شارك أفكارك معنا
3. **تطوير الكود** - انضم إلى فريق التطوير
4. **الترجمة** - ساعد في ترجمة التطبيق للغات أخرى

### إرشادات التطوير
- اتبع معايير الكود المحددة
- اكتب اختبارات للميزات الجديدة
- وثق التغييرات بوضوح
- احترم خصوصية المستخدمين

## الترخيص والحقوق

### الترخيص
- **الكود المصدري**: مفتوح المصدر تحت رخصة MIT
- **المحتوى الإسلامي**: حر ومتاح للجميع
- **العلامات التجارية**: محفوظة لحقوق استوديو seven_code7

### حقوق النشر
```
تطبيق رفيق - رفيقك الإسلامي
© 2024 استوديو seven_code7
جميع الحقوق محفوظة

المطورون: ليث ومحمود
```

## الدعم التقني

### موارد المطورين
- **التوثيق**: هذا الملف والملفات المرفقة
- **الاختبارات**: ملف test-suite.html
- **الأدوات**: أدوات التطوير في المتصفح
- **المجتمع**: منتديات المطورين والمستخدمين

### حل المشاكل التقنية
1. **تحقق من الإصدار** - تأكد من استخدام أحدث إصدار
2. **فحص وحدة التحكم** - ابحث عن رسائل الخطأ
3. **اختبر الاتصال** - تأكد من اتصال الإنترنت
4. **أعد تشغيل التطبيق** - في بعض الحالات يحل هذا المشكلة

## الخاتمة

تطبيق رفيق هو نتيجة جهد كبير وتفاني في تقديم أفضل تجربة إسلامية ممكنة باستخدام أحدث التقنيات. نحن ملتزمون بالتحسين المستمر والابتكار لخدمة المجتمع الإسلامي.

**شكراً لاهتمامك بالتطوير التقني لتطبيق رفيق**

**فريق استوديو seven_code7**