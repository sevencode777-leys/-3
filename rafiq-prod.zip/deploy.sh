#!/bin/bash

# Deployment Script for Rafiq Islamic App
# Usage: ./deploy.sh [environment]
# Environments: development, staging, production

set -e  # Exit on any error

# Configuration
APP_NAME="rafiq"
ENVIRONMENT=${1:-production}
DOCKER_IMAGE="rafiq-app"
DOCKER_TAG="latest"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check requirements
check_requirements() {
    log_info "Checking deployment requirements..."

    # Check if Docker is installed
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed. Please install Docker first."
        exit 1
    fi

    # Check if docker-compose is installed
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose is not installed. Please install Docker Compose first."
        exit 1
    fi

    # Check if git is installed
    if ! command -v git &> /dev/null; then
        log_error "Git is not installed. Please install Git first."
        exit 1
    fi

    log_success "All requirements are met"
}

# Backup current deployment
backup_current() {
    if [ -d "/opt/$APP_NAME" ]; then
        log_info "Creating backup of current deployment..."
        BACKUP_NAME="${APP_NAME}_backup_$(date +%Y%m%d_%H%M%S)"
        cp -r "/opt/$APP_NAME" "/opt/$BACKUP_NAME"
        log_success "Backup created: /opt/$BACKUP_NAME"
    fi
}

# Clone or update repository
prepare_source() {
    log_info "Preparing source code..."

    if [ ! -d "/opt/$APP_NAME" ]; then
        log_info "Cloning repository..."
        git clone https://github.com/sevencodes/rafiq.git "/opt/$APP_NAME"
    else
        log_info "Updating existing repository..."
        cd "/opt/$APP_NAME"
        git pull origin main
    fi

    cd "/opt/$APP_NAME"
    log_success "Source code prepared"
}

# Build Docker image
build_image() {
    log_info "Building Docker image for $ENVIRONMENT environment..."

    cd "/opt/$APP_NAME"

    # Build the image
    docker build -t "$DOCKER_IMAGE:$DOCKER_TAG" \
                 --build-arg ENVIRONMENT="$ENVIRONMENT" \
                 --build-arg BUILD_DATE="$(date -u +'%Y-%m-%dT%H:%M:%SZ')" \
                 --build-arg VCS_REF="$(git rev-parse --short HEAD)" \
                 .

    log_success "Docker image built successfully"
}

# Run tests before deployment
run_tests() {
    log_info "Running pre-deployment tests..."

    cd "/opt/$APP_NAME"

    # Start a test container
    docker run --rm -d \
        --name "${APP_NAME}_test" \
        -p 8080:80 \
        "$DOCKER_IMAGE:$DOCKER_TAG"

    # Wait for container to be ready
    sleep 10

    # Run basic health check
    if curl -f http://localhost:8080/health > /dev/null 2>&1; then
        log_success "Health check passed"
    else
        log_error "Health check failed"
        docker stop "${APP_NAME}_test"
        exit 1
    fi

    # Stop test container
    docker stop "${APP_NAME}_test"
    log_success "Pre-deployment tests passed"
}

# Deploy application
deploy_app() {
    log_info "Deploying application to $ENVIRONMENT environment..."

    cd "/opt/$APP_NAME"

    # Stop existing containers
    docker-compose -f docker-compose.$ENVIRONMENT.yml down || true

    # Start new containers
    docker-compose -f docker-compose.$ENVIRONMENT.yml up -d

    # Wait for services to be ready
    sleep 15

    # Check if deployment was successful
    if curl -f http://localhost/health > /dev/null 2>&1; then
        log_success "Application deployed successfully"
    else
        log_error "Deployment failed - health check unsuccessful"
        exit 1
    fi
}

# Setup SSL certificate (for production)
setup_ssl() {
    if [ "$ENVIRONMENT" = "production" ]; then
        log_info "Setting up SSL certificate..."

        # Check if certbot is installed
        if command -v certbot &> /dev/null; then
            # Generate SSL certificate (example for Let's Encrypt)
            certbot certonly --webroot -w /usr/share/nginx/html -d yourdomain.com --agree-tos --no-eff-email
            log_success "SSL certificate obtained"
        else
            log_warning "Certbot not installed. SSL certificate setup skipped."
        fi
    fi
}

# Cleanup old images and containers
cleanup() {
    log_info "Cleaning up old Docker resources..."

    # Remove unused images
    docker image prune -f

    # Remove stopped containers
    docker container prune -f

    # Remove unused networks
    docker network prune -f

    log_success "Cleanup completed"
}

# Monitor deployment
monitor_deployment() {
    log_info "Monitoring deployment..."

    # Check container status
    if docker-compose -f docker-compose.$ENVIRONMENT.yml ps | grep -q "Up"; then
        log_success "All services are running"

        # Show container logs
        log_info "Recent container logs:"
        docker-compose -f docker-compose.$ENVIRONMENT.yml logs --tail=10
    else
        log_error "Some services are not running properly"
        exit 1
    fi
}

# Install npm dependencies and build the application
install_npm() {
    log_info "Installing npm dependencies and building the application..."

    cd "/opt/$APP_NAME"

    # Install dependencies
    npm install

    # Build the application
    npm run build || true

    # Restart the server
    pm2 restart server || node server.js

    log_success "npm dependencies installed and application built"
}

# Main deployment flow
main() {
    log_info "Starting deployment of $APP_NAME to $ENVIRONMENT environment"

    check_requirements
    backup_current
    prepare_source
    build_image
    run_tests
    deploy_app

    if [ "$ENVIRONMENT" = "production" ]; then
        setup_ssl
    fi

    cleanup
    monitor_deployment
    install_npm

    log_success "Deployment completed successfully!"
    log_info "Application is available at: http://localhost"
    log_info "Health check endpoint: http://localhost/health"
}

# Handle script arguments
case "${1:-}" in
    "development"|"staging"|"production")
        main
        ;;
    "help"|"-h"|"--help")
        echo "Usage: $0 [environment]"
        echo "Environments:"
        echo "  development (default)"
        echo "  staging"
        echo "  production"
        echo ""
        echo "Examples:"
        echo "  $0 development"
        echo "  $0 production"
        ;;
    *)
        log_warning "No environment specified, using 'production' as default"
        main
        ;;
esac