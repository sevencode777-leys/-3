// Global variables
let prayerTimes = {};
let currentSurah = 1;
let currentVerse = 1;
let bookmarks = JSON.parse(localStorage.getItem('bookmarks')) || [];
let khatmaProgress = JSON.parse(localStorage.getItem('khatmaProgress')) || { current: 0, total: 604 };
let tasbihCount = 0;
let tasbihHistory = JSON.parse(localStorage.getItem('tasbihHistory')) || [];
let chatMessages = [];
let audioPlayer = new Audio();
let currentTheme = localStorage.getItem('theme') || 'light';
let currentLanguage = localStorage.getItem('language') || 'ar';
let isOnline = navigator.onLine;
let appSettings = JSON.parse(localStorage.getItem('appSettings')) || {
    fontSize: 'medium',
    fontFamily: 'cairo',
    primaryColor: '#667eea',
    animationSpeed: 'normal',
    autoPlayAudio: false,
    audioQuality: 'medium',
    notificationSound: true,
    volume: 70,
    saveSearchHistory: true,
    analyticsEnabled: false,
    privacyMode: false,
    powerSaving: false,
    autoUpdate: true,
    cacheSize: 'medium',
    autoBackup: true,
    backupFrequency: 'weekly',
    encryptBackup: true
};
let lastReadPosition = JSON.parse(localStorage.getItem('lastReadPosition')) || { surah: 1, verse: 1, timestamp: Date.now() };

const dailyFacts = [
    "القرآن الكريم يحتوي على 114 سورة و 6236 آية.",
    "الصلاة الخمس هي عماد الدين.",
    "الزكاة هي الركن الثالث من أركان الإسلام.",
    "صيام رمضان فريضة على كل مسلم بالغ عاقل.",
    "الحج فريضة على من استطاع إليه سبيلاً.",
    "الإيمان بالله واليوم الآخر هو أساس الإسلام.",
    "الصدق من أفضل الصفات.",
    "الصبر مفتاح الفرج.",
    "العلم نور يقذفه الله في قلب من يشاء.",
    "الدعاء سلاح المؤمن."
];

const morningDhikr = [
    { text: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ", count: 1 },
    { text: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ", count: 1 },
    { text: "رَضِيتُ بِاللَّهِ رَبًّا وَبِالْإِسْلَامِ دِينًا وَبِمُحَمَّدٍ نَبِيًّا", count: 3 },
    { text: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", count: 100 },
    { text: "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ", count: 10 }
];

const eveningDhikr = [
    { text: "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ", count: 1 },
    { text: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ", count: 1 },
    { text: "رَضِيتُ بِاللَّهِ رَبًّا وَبِالْإِسْلَامِ دِينًا وَبِمُحَمَّدٍ نَبِيًّا", count: 3 },
    { text: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", count: 100 },
    { text: "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ", count: 10 }
];

const duas = [
    { title: "دعاء الاستفتاح", text: "اللَّهُمَّ إِنِّي أَسْتَفْتِحُ بِكَ وَأَتَوَكَّلُ عَلَيْكَ وَأُؤْمِنُ بِكَ وَأَنْتَ أَعْلَمُ بِأَمْرِي وَأَنْتَ أَقْدَرُ عَلَى أَمْرِي" },
    { title: "دعاء الركوع", text: "سُبْحَانَ رَبِّيَ الْعَظِيمِ وَبِحَمْدِهِ" },
    { title: "دعاء السجود", text: "سُبْحَانَ رَبِّيَ الْأَعْلَى وَبِحَمْدِهِ" },
    { title: "دعاء الاستغفار", text: "اللَّهُمَّ اغْفِرْ لِي وَارْحَمْنِي وَاهْدِنِي وَعَافِنِي وَارْزُقْنِي" },
    { title: "دعاء التوكل", text: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ وَأَعُوذُ بِكَ مِنَ الْعَجْزِ وَالْكَسَلِ وَأَعُوذُ بِكَ مِنَ الْجُبْنِ وَالْبُخْلِ وَأَعُوذُ بِكَ مِنْ غَلَبَةِ الدَّيْنِ وَقَهْرِ الرِّجَالِ" },
    { title: "دعاء الصباح", text: "اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ" },
    { title: "دعاء المساء", text: "اللَّهُمَّ بِكَ أَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ الْمَصِيرُ" },
    { title: "دعاء الهم", text: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ وَالْعَجْزِ وَالْكَسَلِ وَالْبُخْلِ وَالْجُبْنِ وَضَلَعِ الدَّيْنِ وَغَلَبَةِ الرِّجَالِ" },
    { title: "دعاء الخروج من المنزل", text: "بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ" },
    { title: "دعاء دخول المنزل", text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ الْمَوْلَجِ وَخَيْرَ الْمَخْرَجِ بِسْمِ اللَّهِ وَلَجْنَا وَبِسْمِ اللَّهِ خَرَجْنَا وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا" },
    { title: "دعاء الطعام", text: "اللَّهُمَّ بَارِكْ لَنَا فِيمَا رَزَقْتَنَا وَقِنَا عَذَابَ النَّارِ" },
    { title: "دعاء بعد الطعام", text: "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ" },
    { title: "دعاء السفر", text: "اللَّهُمَّ إِنَّا نَسْأَلُكَ فِي سَفَرِنَا هَذَا الْبِرَّ وَالتَّقْوَى وَمِنَ الْعَمَلِ مَا تَرْضَى" },
    { title: "دعاء الرجوع من السفر", text: "آيِبُونَ تَائِبُونَ عَابِدُونَ لِرَبِّنَا حَامِدُونَ" },
    { title: "دعاء الاستيقاظ", text: "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ" },
    { title: "دعاء النوم", text: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا" },
    { title: "دعاء الوضوء", text: "اللَّهُمَّ اغْفِرْ لِي ذَنْبِي وَوَسِّعْ لِي فِي دَارِي وَبَارِكْ لِي فِي رِزْقِي" },
    { title: "دعاء الدخول إلى المسجد", text: "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ" },
    { title: "دعاء الخروج من المسجد", text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ" },
    { title: "دعاء الزواج", text: "اللَّهُمَّ بَارِكْ لِي فِي أَهْلِي وَبَارِكْ لَهُمْ فِيَّ" },
    { title: "دعاء الولد", text: "اللَّهُمَّ هَبْ لِي مِنْ لَدُنْكَ ذُرِّيَّةً طَيِّبَةً إِنَّكَ سَمِيعُ الدُّعَاءِ" },
    { title: "دعاء الفرج", text: "لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ" },
    { title: "دعاء الغضب", text: "أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ" },
    { title: "دعاء الخوف", text: "حَسْبِيَ اللَّهُ وَنِعْمَ الْوَكِيلُ" },
    { title: "دعاء الرزق", text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا وَرِزْقًا طَيِّبًا وَعَمَلًا مُتَقَبَّلًا" },
    { title: "دعاء الشفاء", text: "اللَّهُمَّ رَبَّ النَّاسِ أَذْهِبِ الْبَأْسَ وَاشْفِ أَنْتَ الشَّافِي لَا شِفَاءَ إِلَّا شِفَاؤُكَ شِفَاءً لَا يُغَادِرُ سَقَمًا" },
    { title: "دعاء الرحمة", text: "رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا" },
    { title: "دعاء التوفيق", text: "اللَّهُمَّ أَعِنِّي وَلَا تُعِنْ عَلَيَّ وَانْصُرْنِي وَلَا تَنْصُرْ عَلَيَّ وَامْكُرْ لِي وَلَا تَمْكُرْ عَلَيَّ وَاهْدِنِي وَيَسِّرْ هُدَايَ إِلَيَّ وَانْصُرْنِي عَلَى مَنْ بَغَى عَلَيَّ رَبِّ اجْعَلْنِي لَكَ شَكَّارًا لَكَ ذَكَّارًا لَكَ رَهَّابًا لَكَ مِطْوَاعًا إِلَيْكَ مُخْبِتًا أَبْوَابًا تَعْبُدُكَ رَبِّ اقْبَلْ تَوْبَتِي وَاغْسِلْ حَوْبَتِي وَأَجِبْ دَعْوَتِي وَثَبِّتْ حُجَّتِي وَسَدِّدْ لِسَانِي وَاهْدِ قَلْبِي وَاسْلُلْ سَخِيمَةَ صَدْرِي" },
    { title: "دعاء اليوم الجديد", text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ هَذَا الْيَوْمِ فَتْحَهُ وَنَصْرَهُ وَنُورَهُ وَبَرَكَتَهُ وَهُدَاهُ وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِيهِ وَشَرِّ مَا بَعْدَهُ" }
];

// Quran Functions
async function loadSurahs() {
    const response = await fetch('https://api.quran.com/api/v4/chapters');
    const data = await response.json();
    const surahList = document.getElementById('surah-list');
    surahList.innerHTML = data.chapters.map(chapter =>
        `<button onclick="loadSurah(${chapter.id})">${chapter.name_arabic} (${chapter.translated_name.name})</button>`
    ).join('');
}

async function loadSurah(surahId, targetVerse = null) {
    currentSurah = surahId;
    const response = await fetch(`https://api.quran.com/api/v4/verses/by_chapter/${surahId}?language=ar&words=false&translations=131`);
    const data = await response.json();
    const verseDisplay = document.getElementById('verse-display');

    verseDisplay.innerHTML = `
        <div class="surah-header">
            <h3>سورة ${data.verses[0].chapter.name_arabic}</h3>
            <p>عدد الآيات: ${data.verses.length}</p>
            <div class="surah-navigation">
                <button onclick="goToLastReadPosition()">العودة لآخر مكان قرأت</button>
                <button onclick="showVerseSelector()">الانتقال لآية محددة</button>
                <button onclick="showSurahSelector()">تغيير السورة</button>
            </div>
        </div>
        <div class="verses-container">
            ${data.verses.map(verse => `
                <div class="verse ${verse.verse_number === currentVerse ? 'current-verse' : ''}" data-verse="${verse.verse_number}" onclick="selectVerse(${verse.verse_number})">
                    <div class="verse-header">
                        <span class="verse-number">${verse.verse_number}</span>
                        <div class="verse-actions">
                            <button onclick="event.stopPropagation(); bookmarkVerse(${verse.verse_number})" title="حفظ العلامة">🔖</button>
                            <button onclick="event.stopPropagation(); playVerse(${verse.verse_number})" title="استماع">🔊</button>
                            <button onclick="event.stopPropagation(); showTafsir(${verse.verse_number})" title="تفسير">📖</button>
                        </div>
                    </div>
                    <p class="verse-text">${verse.text_uthmani}</p>
                    <p class="translation">${verse.translations[0].text}</p>
                </div>
            `).join('')}
        </div>
    `;

    // Scroll to target verse or last read position
    if (targetVerse) {
        scrollToVerse(targetVerse);
    } else if (surahId === lastReadPosition.surah) {
        scrollToVerse(lastReadPosition.verse);
    }

    updateKhatmaProgress();
    updateReadingProgress();
}

async function showTafsir(verseNumber) {
    const response = await fetch(`https://api.quran.com/api/v4/tafsirs/169/verses/${currentSurah}:${verseNumber}`);
    const data = await response.json();
    alert(data.tafsir.text); // Simple alert, can improve to modal
}

function bookmarkVerse(verseNumber) {
    const bookmark = { surah: currentSurah, verse: verseNumber };
    if (!bookmarks.some(b => b.surah === currentSurah && b.verse === verseNumber)) {
        bookmarks.push(bookmark);
        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
        alert('تم حفظ العلامة');
    }
}

function playVerse(verseNumber) {
    const reciter = document.getElementById('reciter-select').value;
    const audioUrl = `https://cdn.islamic.network/quran/audio/128/${reciter}/${currentSurah}${verseNumber.toString().padStart(3, '0')}.mp3`;
    audioPlayer.src = audioUrl;
    audioPlayer.play();
}

function playAudio() {
    audioPlayer.play();
}

function pauseAudio() {
    audioPlayer.pause();
}

function startKhatma() {
    khatmaProgress.current = 0;
    localStorage.setItem('khatmaProgress', JSON.stringify(khatmaProgress));
    updateKhatmaProgress();
}

function updateKhatmaProgress() {
    const progress = document.getElementById('khatma-progress');
    const percentage = Math.round((khatmaProgress.current / khatmaProgress.total) * 100);
    progress.innerHTML = `
        <div class="khatma-progress">
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${percentage}%"></div>
            </div>
            <p>الختمة: ${khatmaProgress.current} / ${khatmaProgress.total} (${percentage}%)</p>
        </div>
    `;
}

function selectVerse(verseNumber) {
    // Remove current-verse class from all verses
    document.querySelectorAll('.verse').forEach(verse => {
        verse.classList.remove('current-verse');
    });

    // Add current-verse class to selected verse
    const selectedVerse = document.querySelector(`[data-verse="${verseNumber}"]`);
    if (selectedVerse) {
        selectedVerse.classList.add('current-verse');
        currentVerse = verseNumber;

        // Save reading position
        saveReadingPosition();

        // Scroll to verse
        scrollToVerse(verseNumber);

        // Update khatma progress if reading new verse
        updateKhatmaIfNewVerse();
    }
}

function scrollToVerse(verseNumber) {
    const verseElement = document.querySelector(`[data-verse="${verseNumber}"]`);
    if (verseElement) {
        verseElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

function saveReadingPosition() {
    lastReadPosition = {
        surah: currentSurah,
        verse: currentVerse,
        timestamp: Date.now()
    };
    localStorage.setItem('lastReadPosition', JSON.stringify(lastReadPosition));
}

function goToLastReadPosition() {
    if (lastReadPosition.surah && lastReadPosition.verse) {
        loadSurah(lastReadPosition.surah, lastReadPosition.verse);
    }
}

function showVerseSelector() {
    const modal = createModal(`
        <h3>الانتقال لآية محددة</h3>
        <div class="verse-selector">
            <input type="number" id="target-verse" placeholder="رقم الآية" min="1" max="286">
            <button onclick="goToVerse()">انتقال</button>
        </div>
    `);
}

function goToVerse() {
    const targetVerse = parseInt(document.getElementById('target-verse').value);
    if (targetVerse && targetVerse > 0) {
        selectVerse(targetVerse);
        closeModal();
    }
}

function showSurahSelector() {
    // Get list of surahs for quick navigation
    fetch('https://api.quran.com/api/v4/chapters')
        .then(response => response.json())
        .then(data => {
            const modal = createModal(`
                <h3>اختيار السورة</h3>
                <div class="surah-quick-select">
                    ${data.chapters.slice(0, 20).map(chapter =>
                        `<button onclick="loadSurah(${chapter.id}); closeModal();">${chapter.name_arabic}</button>`
                    ).join('')}
                </div>
            `);
        });
}

function updateKhatmaIfNewVerse() {
    // Calculate verse position in Quran
    let versePosition = 0;
    for (let i = 1; i < currentSurah; i++) {
        // This is a simplified calculation - in real implementation you'd need actual verse counts
        versePosition += 20; // Average verses per surah approximation
    }
    versePosition += currentVerse;

    if (versePosition > khatmaProgress.current) {
        khatmaProgress.current = versePosition;
        localStorage.setItem('khatmaProgress', JSON.stringify(khatmaProgress));
        updateKhatmaProgress();
    }
}

function updateReadingProgress() {
    const progressElement = document.getElementById('reading-progress');
    if (progressElement) {
        const surahProgress = Math.round((currentVerse / 286) * 100); // Assuming max 286 verses
        progressElement.innerHTML = `
            <div class="reading-progress">
                <p>السورة الحالية: ${currentVerse} / 286</p>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${surahProgress}%"></div>
                </div>
            </div>
        `;
    }
}

// Modal utility functions
function createModal(content) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            ${content}
        </div>
    `;
    document.body.appendChild(modal);

    // Add modal styles if not exists
    if (!document.getElementById('modal-styles')) {
        const styles = document.createElement('style');
        styles.id = 'modal-styles';
        styles.textContent = `
            .modal { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; }
            .modal-content { background: var(--card-background); padding: 2rem; border-radius: 10px; max-width: 90%; max-height: 90%; overflow-y: auto; }
            .close { position: absolute; top: 10px; right: 15px; font-size: 25px; cursor: pointer; color: var(--text-color); }
            .verse-selector, .surah-quick-select { margin-top: 1rem; }
            .verse-selector input { padding: 0.5rem; margin: 0.5rem; border: 1px solid var(--border-color); border-radius: 5px; }
            .surah-quick-select { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 0.5rem; }
            .surah-quick-select button { padding: 0.5rem; background: var(--primary-color); color: white; border: none; border-radius: 5px; cursor: pointer; }
        `;
        document.head.appendChild(styles);
    }

    return modal;
}

function closeModal() {
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.remove();
    }
}

// Calendar Functions
async function loadHijriDate() {
    const response = await fetch('https://api.aladhan.com/v1/gToH');
    const data = await response.json();
    const hijri = data.data.hijri;
    document.getElementById('hijri-date').innerHTML = `${hijri.day} ${hijri.month.ar} ${hijri.year}`;
    calculateRamadanCountdown(hijri);
    showRamadanEidMessages(hijri);
    showDailyFact();
}

function calculateRamadanCountdown(hijri) {
    // Approximate Ramadan start (adjust based on actual)
    const ramadanStart = { year: 1446, month: 9, day: 1 }; // Ramadan 1446
    let daysUntilRamadan = 0;
    if (hijri.year < ramadanStart.year || (hijri.year === ramadanStart.year && hijri.month.number < ramadanStart.month)) {
        daysUntilRamadan = (ramadanStart.year - hijri.year) * 354 + (ramadanStart.month - hijri.month.number) * 29 + (ramadanStart.day - hijri.day);
    }
    document.getElementById('ramadan-countdown').innerHTML = `أيام حتى رمضان: ${daysUntilRamadan}`;
}

function showRamadanEidMessages(hijri) {
    let message = '';
    if (hijri.month.number === 9) { // Ramadan
        message = 'رمضان كريم! شهر البركة والرحمة.';
    } else if (hijri.month.number === 10 && hijri.day <= 3) { // Eid al-Fitr
        message = 'عيد الفطر مبارك! تقبل الله منا ومنكم.';
    } else if (hijri.month.number === 12 && hijri.day <= 3) { // Eid al-Adha
        message = 'عيد الأضحى مبارك! تقبل الله منا ومنكم.';
    }
    if (message) {
        document.getElementById('calendar-display').innerHTML = `<p class="eid-message">${message}</p>`;
    }
}

function showDailyFact() {
    const today = new Date().toDateString();
    let lastShown = localStorage.getItem('lastFactDate');
    let factIndex = localStorage.getItem('factIndex') || 0;
    if (lastShown !== today) {
        factIndex = (parseInt(factIndex) + 1) % dailyFacts.length;
        localStorage.setItem('factIndex', factIndex);
        localStorage.setItem('lastFactDate', today);
    }
    document.getElementById('daily-fact').innerHTML = `<p><strong>حقيقة يومية:</strong> ${dailyFacts[factIndex]}</p>`;
}

// Hadith Functions
let allHadiths = [];

async function loadHadiths() {
    const response = await fetch('hadiths.json');
    allHadiths = await response.json();
    displayHadiths(allHadiths);
}

function displayHadiths(hadiths) {
    const hadithList = document.getElementById('hadith-list');
    hadithList.innerHTML = hadiths.map(hadith =>
        `<button onclick="showHadith(${hadith.id})">${hadith.text.substring(0, 50)}...</button>`
    ).join('');
}

let searchHistory = JSON.parse(localStorage.getItem('searchHistory')) || [];
let searchIndex = {}; // For faster searching

function searchHadiths() {
    const query = document.getElementById('hadith-search').value.trim();
    if (!query) {
        displayHadiths(allHadiths);
        return;
    }

    // Add to search history
    if (!searchHistory.includes(query)) {
        searchHistory.unshift(query);
        if (searchHistory.length > 10) searchHistory.pop();
        localStorage.setItem('searchHistory', JSON.stringify(searchHistory));
    }

    // Show search suggestions
    showSearchSuggestions(query);

    // Perform search
    const results = performAdvancedSearch(query, allHadiths);
    displaySearchResults(results, query);
}

function performAdvancedSearch(query, hadiths) {
    const searchTerms = query.toLowerCase().split(' ').filter(term => term.length > 0);
    const results = [];

    hadiths.forEach(hadith => {
        let score = 0;
        const searchableText = `${hadith.text} ${hadith.translation} ${hadith.explanation} ${hadith.source}`.toLowerCase();

        searchTerms.forEach(term => {
            // Exact phrase match gets highest score
            if (searchableText.includes(query.toLowerCase())) {
                score += 100;
            }
            // Individual word matches
            else if (searchableText.includes(term)) {
                score += term.length > 2 ? 10 : 5; // Longer words get higher score
            }
        });

        if (score > 0) {
            results.push({
                hadith: hadith,
                score: score,
                relevance: calculateRelevance(query, hadith)
            });
        }
    });

    // Sort by score and relevance
    return results.sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        return b.relevance - a.relevance;
    }).slice(0, 50); // Limit results
}

function calculateRelevance(query, hadith) {
    const queryLower = query.toLowerCase();
    let relevance = 0;

    // Boost relevance for matches in different fields
    if (hadith.text.toLowerCase().includes(queryLower)) relevance += 3;
    if (hadith.translation.toLowerCase().includes(queryLower)) relevance += 2;
    if (hadith.explanation.toLowerCase().includes(queryLower)) relevance += 1;
    if (hadith.source.toLowerCase().includes(queryLower)) relevance += 0.5;

    return relevance;
}

function displaySearchResults(results, query) {
    const hadithList = document.getElementById('hadith-list');
    const hadithDisplay = document.getElementById('hadith-display');

    if (results.length === 0) {
        hadithList.innerHTML = `<p class="no-results">لا توجد نتائج للبحث عن: "${query}"</p>`;
        hadithDisplay.innerHTML = '';
        return;
    }

    hadithList.innerHTML = `
        <div class="search-results-header">
            <p>تم العثور على ${results.length} نتيجة لـ "${query}"</p>
            <div class="search-filters">
                <button onclick="filterBySource('البخاري')" class="filter-btn">البخاري</button>
                <button onclick="filterBySource('مسلم')" class="filter-btn">مسلم</button>
                <button onclick="filterBySource('الترمذي')" class="filter-btn">الترمذي</button>
                <button onclick="clearFilters()" class="filter-btn clear">مسح الفلاتر</button>
            </div>
        </div>
        ${results.map(result =>
            `<div class="search-result-item" onclick="showHadithSearchResult(${result.hadith.id})">
                <div class="result-score">الصلة: ${Math.round(result.score)}%</div>
                <p class="result-text">${highlightSearchTerms(result.hadith.text.substring(0, 100), query)}...</p>
                <div class="result-meta">
                    <span class="result-source">${result.hadith.source}</span>
                </div>
            </div>`
        ).join('')}
    `;

    hadithDisplay.innerHTML = '';
}

function showHadithSearchResult(id) {
    const hadith = allHadiths.find(h => h.id === id);
    if (hadith) {
        document.getElementById('hadith-display').innerHTML = `
            <div class="hadith-full">
                <h3>الحديث</h3>
                <p class="hadith-text">${hadith.text}</p>
                <h4>المعنى</h4>
                <p class="hadith-translation">${hadith.translation}</p>
                <h4>الشرح</h4>
                <p class="hadith-explanation">${hadith.explanation}</p>
                <div class="hadith-footer">
                    <span class="hadith-source">المصدر: ${hadith.source}</span>
                    <button onclick="bookmarkHadith(${hadith.id})">حفظ في المفضلة</button>
                </div>
            </div>
        `;
    }
}

function highlightSearchTerms(text, query) {
    if (!query) return text;
    const terms = query.split(' ');
    let highlightedText = text;

    terms.forEach(term => {
        if (term.length > 2) {
            const regex = new RegExp(`(${term})`, 'gi');
            highlightedText = highlightedText.replace(regex, '<mark>$1</mark>');
        }
    });

    return highlightedText;
}

function showSearchSuggestions(query) {
    if (query.length < 2) return;

    const suggestions = generateSearchSuggestions(query);
    if (suggestions.length > 0) {
        const suggestionContainer = document.createElement('div');
        suggestionContainer.className = 'search-suggestions';
        suggestionContainer.innerHTML = `
            <p>اقتراحات البحث:</p>
            ${suggestions.map(suggestion =>
                `<button onclick="applySuggestion('${suggestion}')">${suggestion}</button>`
            ).join('')}
        `;

        // Remove existing suggestions
        const existing = document.querySelector('.search-suggestions');
        if (existing) existing.remove();

        document.getElementById('hadith-search').parentNode.appendChild(suggestionContainer);
    }
}

function generateSearchSuggestions(query) {
    const suggestions = [];
    const commonTerms = ['الصلاة', 'الصوم', 'الزكاة', 'الحج', 'الإيمان', 'التقوى', 'الصبر', 'الشكر'];

    commonTerms.forEach(term => {
        if (term.includes(query) && term !== query) {
            suggestions.push(term);
        }
    });

    return suggestions.slice(0, 3);
}

function applySuggestion(suggestion) {
    document.getElementById('hadith-search').value = suggestion;
    document.querySelector('.search-suggestions').remove();
    searchHadiths();
}

function clearFilters() {
    displayHadiths(allHadiths);
    document.getElementById('hadith-search').value = '';
}

function filterBySource(source) {
    const query = document.getElementById('hadith-search').value;
    let filtered = allHadiths;

    if (query) {
        const results = performAdvancedSearch(query, allHadiths);
        filtered = results.map(r => r.hadith);
    }

    filtered = filtered.filter(hadith => hadith.source.includes(source));
    displayHadiths(filtered);
}

function bookmarkHadith(hadithId) {
    const hadith = allHadiths.find(h => h.id === hadithId);
    if (hadith && !bookmarks.some(b => b.type === 'hadith' && b.id === hadithId)) {
        bookmarks.push({
            type: 'hadith',
            id: hadithId,
            timestamp: Date.now()
        });
        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
        showNotification('تم الحفظ', 'تم حفظ الحديث في المفضلة');
    }
}

// Quran Search Functions
let quranData = {};
let currentSearchType = 'text';

async function loadQuranData() {
    try {
        // Load Quran data for searching
        const response = await fetch('https://api.quran.com/api/v4/chapters');
        const chaptersData = await response.json();

        quranData.chapters = chaptersData.chapters;
        quranData.searchIndex = await buildQuranSearchIndex();
    } catch (error) {
        console.error('Error loading Quran data:', error);
    }
}

async function buildQuranSearchIndex() {
    const index = {};
    for (let chapter = 1; chapter <= 114; chapter++) {
        try {
            const response = await fetch(`https://api.quran.com/api/v4/verses/by_chapter/${chapter}?language=ar&words=false&translations=131`);
            const data = await response.json();

            data.verses.forEach(verse => {
                const key = `${chapter}:${verse.verse_number}`;
                index[key] = {
                    text: verse.text_uthmani,
                    translation: verse.translations[0].text,
                    surah: verse.chapter.name_arabic,
                    surahNumber: chapter,
                    verseNumber: verse.verse_number
                };
            });
        } catch (error) {
            console.error(`Error loading chapter ${chapter}:`, error);
        }
    }
    return index;
}

function searchQuran() {
    const query = document.getElementById('quran-search').value.trim();
    const resultsContainer = document.getElementById('quran-search-results');

    if (!query) {
        resultsContainer.innerHTML = '';
        return;
    }

    if (Object.keys(quranData.searchIndex || {}).length === 0) {
        resultsContainer.innerHTML = '<p>جاري تحميل بيانات القرآن...</p>';
        loadQuranData().then(() => searchQuran());
        return;
    }

    const results = performQuranSearch(query);
    displayQuranSearchResults(results, query);
}

function performQuranSearch(query) {
    const results = [];
    const searchIndex = quranData.searchIndex;

    Object.entries(searchIndex).forEach(([key, verse]) => {
        let score = 0;
        const searchText = currentSearchType === 'text' ? verse.text :
                          currentSearchType === 'translation' ? verse.translation :
                          `${verse.text} ${verse.translation}`;

        const queryLower = query.toLowerCase();
        const textLower = searchText.toLowerCase();

        if (textLower.includes(queryLower)) {
            // Calculate relevance score
            if (verse.text.toLowerCase().includes(queryLower)) score += 10;
            if (verse.translation.toLowerCase().includes(queryLower)) score += 5;

            // Boost score for exact matches
            if (textLower === queryLower) score += 50;

            results.push({
                key,
                verse,
                score,
                snippet: getSearchSnippet(verse, query)
            });
        }
    });

    return results.sort((a, b) => b.score - a.score).slice(0, 20);
}

function getSearchSnippet(verse, query) {
    const text = currentSearchType === 'text' ? verse.text : verse.translation;
    const queryLower = query.toLowerCase();
    const textLower = text.toLowerCase();

    const index = textLower.indexOf(queryLower);
    if (index === -1) return text.substring(0, 100);

    const start = Math.max(0, index - 30);
    const end = Math.min(text.length, index + query.length + 30);

    let snippet = text.substring(start, end);
    if (start > 0) snippet = '...' + snippet;
    if (end < text.length) snippet = snippet + '...';

    return snippet;
}

function displayQuranSearchResults(results, query) {
    const resultsContainer = document.getElementById('quran-search-results');

    if (results.length === 0) {
        resultsContainer.innerHTML = `<p class="no-results">لا توجد نتائج للبحث عن: "${query}"</p>`;
        return;
    }

    resultsContainer.innerHTML = `
        <div class="quran-search-header">
            <p>تم العثور على ${results.length} نتيجة لـ "${query}"</p>
        </div>
        <div class="quran-search-results">
            ${results.map(result => `
                <div class="quran-search-item" onclick="goToQuranVerse('${result.key}')">
                    <div class="verse-reference">
                        ${result.verse.surah} (${result.verse.surahNumber}:${result.verse.verseNumber})
                    </div>
                    <div class="search-snippet">
                        ${highlightSearchTerms(result.snippet, query)}
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

function goToQuranVerse(key) {
    const [surahNumber, verseNumber] = key.split(':').map(Number);
    loadSurah(surahNumber, verseNumber);
    document.getElementById('quran-search-results').innerHTML = '';
    document.getElementById('quran-search').value = '';
}

function updateSearchType() {
    const select = document.getElementById('search-type');
    currentSearchType = select.value;
    searchQuran(); // Re-search with new type
}

function clearQuranSearch() {
    document.getElementById('quran-search').value = '';
    document.getElementById('quran-search-results').innerHTML = '';
}

function showHadith(id) {
    fetch('hadiths.json')
        .then(response => response.json())
        .then(hadiths => {
            const hadith = hadiths.find(h => h.id === id);
            document.getElementById('hadith-display').innerHTML = `
                <h3>${hadith.text}</h3>
                <p><strong>الترجمة:</strong> ${hadith.translation}</p>
                <p><strong>الشرح:</strong> ${hadith.explanation}</p>
                <p><strong>المصدر:</strong> ${hadith.source}</p>
            `;
        });
}

// Dhikr Functions
function showMorningDhikr() {
    displayDhikr(morningDhikr, 'صباح');
}

function showEveningDhikr() {
    displayDhikr(eveningDhikr, 'مساء');
}

function displayDhikr(dhikrList, time) {
    const container = document.getElementById('dhikr-display');
    container.innerHTML = `<h3>أذكار ال${time}</h3>` + dhikrList.map(dhikr =>
        `<div class="dhikr-item">
            <p>${dhikr.text}</p>
            <p>عدد المرات: ${dhikr.count}</p>
            <button onclick="reciteDhikr('${dhikr.text}', ${dhikr.count})">تلاوة</button>
        </div>`
    ).join('');
}

function reciteDhikr(text, count) {
    for (let i = 0; i < count; i++) {
        setTimeout(() => speak(text), i * 2000); // Speak each time with delay
    }
}

// Dua Functions
function loadDuas() {
    const duaList = document.getElementById('dua-list');
    duaList.innerHTML = duas.map((dua, index) =>
        `<button onclick="showDua(${index})">${dua.title}</button>`
    ).join('');
}

function showDua(index) {
    const dua = duas[index];
    document.getElementById('dua-display').innerHTML = `
        <h3>${dua.title}</h3>
        <p>${dua.text}</p>
        <button onclick="speakDua('${dua.text}')">تلاوة</button>
    `;
}

function speakDua(text) {
    speak(text);
}

// Qibla Functions
function getQiblaDirection() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            const qiblaAngle = calculateQibla(lat, lng);
            document.getElementById('qibla-direction').innerHTML = `اتجاه القبلة: ${qiblaAngle.toFixed(1)} درجة`;
            drawCompass(qiblaAngle);
        });
    } else {
        document.getElementById('qibla-direction').innerHTML = 'الموقع الجغرافي غير مدعوم';
    }
}

function calculateQibla(lat, lng) {
    const meccaLat = 21.4225;
    const meccaLng = 39.8262;
    const dLng = (meccaLng - lng) * Math.PI / 180;
    const lat1 = lat * Math.PI / 180;
    const lat2 = meccaLat * Math.PI / 180;
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    let bearing = Math.atan2(y, x) * 180 / Math.PI;
    return (bearing + 360) % 360;
}

function drawCompass(angle) {
    const canvas = document.getElementById('compass');
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.beginPath();
    ctx.arc(100, 100, 80, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(100, 100);
    ctx.lineTo(100 + 70 * Math.sin(angle * Math.PI / 180), 100 - 70 * Math.cos(angle * Math.PI / 180));
    ctx.strokeStyle = 'red';
    ctx.stroke();
}

// Prayer Times Functions
async function loadPrayerTimes() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async position => {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            const response = await fetch(`https://api.aladhan.com/v1/timings?latitude=${lat}&longitude=${lng}&method=2`);
            const data = await response.json();
            const timings = data.data.timings;
            prayerTimes = timings;
            document.getElementById('prayer-times').innerHTML = `
                <p>الفجر: ${timings.Fajr}</p>
                <p>الظهر: ${timings.Dhuhr}</p>
                <p>العصر: ${timings.Asr}</p>
                <p>المغرب: ${timings.Maghrib}</p>
                <p>العشاء: ${timings.Isha}</p>
            `;
            startCountdown();
            localStorage.setItem('prayerTimes', JSON.stringify({timings, date: data.data.date.readable}));
        });
    }
}

function startCountdown() {
    setInterval(() => {
        const now = new Date();
        const currentTime = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
        let nextPrayer = null;
        let timeToNext = Infinity;
        for (const [prayer, time] of Object.entries(prayerTimes)) {
            const [h, m] = time.split(':').map(Number);
            const prayerTime = h * 3600 + m * 60;
            if (prayerTime > currentTime) {
                const diff = prayerTime - currentTime;
                if (diff < timeToNext) {
                    timeToNext = diff;
                    nextPrayer = prayer;
                }
            }
        }
        if (nextPrayer) {
            const hours = Math.floor(timeToNext / 3600);
            const minutes = Math.floor((timeToNext % 3600) / 60);
            const seconds = timeToNext % 60;
            document.getElementById('countdown').innerHTML = `الصلاة القادمة: ${nextPrayer} بعد ${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        } else {
            document.getElementById('countdown').innerHTML = 'جميع الصلوات انتهت اليوم';
        }
    }, 1000);
}

let notificationSettings = JSON.parse(localStorage.getItem('notificationSettings')) || {
    enabled: false,
    reminderTime: 10, // minutes before prayer
    soundEnabled: true,
    vibrationEnabled: true,
    prayers: {
        fajr: true,
        dhuhr: true,
        asr: true,
        maghrib: true,
        isha: true
    }
};

function togglePrayerReminders() {
    if ('Notification' in window) {
        if (!notificationSettings.enabled) {
            Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                    notificationSettings.enabled = true;
                    localStorage.setItem('notificationSettings', JSON.stringify(notificationSettings));
                    schedulePrayerNotifications();
                    updateNotificationButton();
                    showNotification('تم تفعيل تذكيرات الصلاة', 'سيتم تذكيرك قبل كل صلاة');
                }
            });
        } else {
            notificationSettings.enabled = false;
            localStorage.setItem('notificationSettings', JSON.stringify(notificationSettings));
            updateNotificationButton();
            showNotification('تم تعطيل تذكيرات الصلاة', 'لن تتلقى تذكيرات الصلاة بعد الآن');
        }
    }
}

function schedulePrayerNotifications() {
    if (!notificationSettings.enabled || !prayerTimes) return;

    // Clear existing notifications
    if (window.prayerNotificationTimeouts) {
        window.prayerNotificationTimeouts.forEach(timeout => clearTimeout(timeout));
    }
    window.prayerNotificationTimeouts = [];

    for (const [prayer, time] of Object.entries(prayerTimes)) {
        if (!notificationSettings.prayers[prayer.toLowerCase()]) continue;

        const [h, m] = time.split(':').map(Number);
        const now = new Date();
        const prayerTime = new Date();
        prayerTime.setHours(h, m - notificationSettings.reminderTime, 0, 0);

        if (prayerTime > now) {
            const timeoutId = setTimeout(() => {
                showPrayerNotification(prayer, time);
                playPrayerSound(prayer);
                if (notificationSettings.vibrationEnabled && 'vibrate' in navigator) {
                    navigator.vibrate([200, 100, 200]);
                }
            }, prayerTime.getTime() - now.getTime());

            window.prayerNotificationTimeouts.push(timeoutId);
        }
    }
}

function showPrayerNotification(prayer, time) {
    const prayerNames = {
        Fajr: 'الفجر',
        Dhuhr: 'الظهر',
        Asr: 'العصر',
        Maghrib: 'المغرب',
        Isha: 'العشاء'
    };

    const prayerName = prayerNames[prayer] || prayer;

    if ('Notification' in window && Notification.permission === 'granted') {
        const notification = new Notification(`🕌 صلاة ${prayerName}`, {
            body: `حان وقت صلاة ${prayerName}. موعد الصلاة: ${time}`,
            icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">🕌</text></svg>',
            badge: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">🕌</text></svg>',
            tag: `prayer-${prayer}`,
            requireInteraction: false,
            silent: !notificationSettings.soundEnabled
        });

        notification.onclick = function() {
            showSection('prayer');
            window.focus();
            notification.close();
        };

        // Auto close after 30 seconds
        setTimeout(() => notification.close(), 30000);
    }
}

function playPrayerSound(prayer) {
    if (!notificationSettings.soundEnabled) return;

    // Use Web Speech API for prayer call
    const prayerCalls = {
        Fajr: 'صلاة الفجر',
        Dhuhr: 'صلاة الظهر',
        Asr: 'صلاة العصر',
        Maghrib: 'صلاة المغرب',
        Isha: 'صلاة العشاء'
    };

    const utterance = new SpeechSynthesisUtterance(prayerCalls[prayer] || `صلاة ${prayer}`);
    utterance.lang = 'ar-SA';
    utterance.rate = 0.8;
    utterance.pitch = 1;
    utterance.volume = 0.7;

    // Add echo effect by repeating with slight delay
    setTimeout(() => {
        speechSynthesis.speak(utterance);
    }, 100);
}

function updateNotificationButton() {
    const button = document.querySelector('#prayer button');
    if (button) {
        button.textContent = notificationSettings.enabled ? 'تعطيل التذكيرات' : 'تفعيل التذكيرات';
    }
}

function showNotification(title, body) {
    if ('Notification' in window && Notification.permission === 'granted') {
        const notification = new Notification(title, {
            body: body,
            icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">🕌</text></svg>'
        });

        setTimeout(() => notification.close(), 5000);
    }
}

// Tasbih Functions
function incrementTasbih() {
    tasbihCount++;
    document.getElementById('tasbih-counter').innerHTML = tasbihCount;
    if (tasbihCount % 33 === 0) {
        tasbihHistory.push(new Date().toLocaleString());
        localStorage.setItem('tasbihHistory', JSON.stringify(tasbihHistory));
        updateTasbihHistory();
    }
}

function resetTasbih() {
    tasbihCount = 0;
    document.getElementById('tasbih-counter').innerHTML = tasbihCount;
}

function updateTasbihHistory() {
    const history = document.getElementById('tasbih-history');
    history.innerHTML = tasbihHistory.map(entry => `<p>${entry}</p>`).join('');
}

// AI Chatbot Functions
let aiKnowledgeBase = {};
let chatHistory = JSON.parse(localStorage.getItem('chatHistory')) || [];
let aiLearningData = JSON.parse(localStorage.getItem('aiLearningData')) || {};

function initializeAI() {
    // Build knowledge base from existing data
    buildAIKnowledgeBase();
}

function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    if (!message) return;

    addMessage('أنت: ' + message);

    // Save user message to history
    chatHistory.push({
        type: 'user',
        message: message,
        timestamp: Date.now()
    });

    // Get AI response
    const response = getAIResponse(message);
    addMessage('رفيق: ' + response);

    // Save AI response to history
    chatHistory.push({
        type: 'ai',
        message: response,
        timestamp: Date.now()
    });

    // Learn from interaction
    learnFromInteraction(message, response);

    input.value = '';
    saveChatData();
}

function addMessage(message) {
    const messages = document.getElementById('chat-messages');
    const messageElement = document.createElement('div');
    messageElement.className = message.startsWith('أنت:') ? 'user-message' : 'ai-message';
    messageElement.innerHTML = `<p>${message}</p>`;
    messages.appendChild(messageElement);
    messages.scrollTop = messages.scrollHeight;
}

function getAIResponse(message) {
    const lowerMessage = message.toLowerCase();

    // Check for exact matches in knowledge base
    if (aiKnowledgeBase[message]) {
        return aiKnowledgeBase[message];
    }

    // Pattern matching for common questions
    const patterns = [
        {
            pattern: /كيف.*صلاة|كيفية.*الصلاة|طريقة.*الصلاة/,
            response: "الصلاة تؤدى بالوضوء أولاً، ثم النية، ثم تكبيرة الإحرام، قراءة الفاتحة، الركوع، السجود، والتشهد الأخير. للمزيد من التفاصيل يمكنك زيارة قسم أوقات الصلاة."
        },
        {
            pattern: /ما هي.*اركان.*الإسلام|أركان.*الإسلام/,
            response: "أركان الإسلام خمسة: 1) الشهادتان، 2) إقام الصلاة، 3) إيتاء الزكاة، 4) صوم رمضان، 5) حج البيت لمن استطاع إليه سبيلاً."
        },
        {
            pattern: /ما هي.*اركان.*الإيمان|أركان.*الإيمان/,
            response: "أركان الإيمان ستة: 1) الإيمان بالله، 2) الإيمان بالملائكة، 3) الإيمان بالكتب، 4) الإيمان بالرسل، 5) الإيمان باليوم الآخر، 6) الإيمان بالقدر خيره وشره."
        },
        {
            pattern: /كيف.*أتوب|التوبة|كيفية.*التوبة/,
            response: "التوبة تكون بالندم على الذنب، والإقلاع عنه فوراً، وعدم العودة إليه، ورد الحقوق إلى أصحابها إن أمكن. قال تعالى: 'وَتُوبُوا إِلَى اللَّهِ جَمِيعًا أَيُّهَ الْمُؤْمِنُونَ لَعَلَّكُمْ تُفْلِحُونَ'."
        },
        {
            pattern: /كيف.*أقرأ.*القرآن|قراءة.*القرآن/,
            response: "ابدأ بتلاوة القرآن بتدبر وخشوع، مع الاستعاذة بالله من الشيطان الرجيم، وقل 'بسم الله الرحمن الرحيم' قبل كل سورة إلا التوبة. يمكنك زيارة قسم القرآن في التطبيق للمزيد."
        },
        {
            pattern: /ما هي.*الأذكار|أذكار.*الصباح|أذكار.*المساء/,
            response: "الأذكار هي أذكار الصباح والمساء، وتشمل أذكار النوم والاستيقاظ والطعام والخروج من المنزل. يمكنك العثور عليها في قسم الأذكار بالتطبيق."
        },
        {
            pattern: /كيف.*أصوم|الصوم|صيام.*رمضان/,
            response: "الصوم في رمضان فريضة على كل مسلم بالغ عاقل، من طلوع الفجر إلى غروب الشمس، مع النية في الليلة السابقة. يمكنك متابعة أوقات الإمساك والإفطار في قسم التقويم."
        },
        {
            pattern: /ما هي.*الزكاة|كيف.*أزكي|حساب.*الزكاة/,
            response: "الزكاة ركن من أركان الإسلام، وهي إخراج 2.5% من المال المدخر لمدة عام كامل للفقراء والمحتاجين. يمكنك استشارة عالم موثوق لحساب زكاتك بدقة."
        },
        {
            pattern: /كيف.*أحج|الحج|مناسك.*الحج/,
            response: "الحج فريضة على من استطاع إليه سبيلاً، ويشمل الإحرام، الطواف، السعي، الوقوف بعرفة، رمي الجمرات، والحلق. يجب الاستعداد جيداً قبل السفر."
        },
        {
            pattern: /ما هي.*السنن|السنة.*النبوية/,
            response: "السنة النبوية هي أقوال وأفعال وتقريرات النبي محمد صلى الله عليه وسلم، وهي المصدر الثاني للتشريع الإسلامي بعد القرآن الكريم."
        }
    ];

    // Check patterns
    for (const pattern of patterns) {
        if (pattern.pattern.test(lowerMessage)) {
            return pattern.response;
        }
    }

    // Context-aware responses based on current section
    const currentSection = document.querySelector('.section.active')?.id;
    if (currentSection === 'quran' && (lowerMessage.includes('سورة') || lowerMessage.includes('آية'))) {
        return "يمكنك البحث في القرآن أو تصفح السور المختلفة في قسم القرآن الكريم. هل تريد المساعدة في سورة معينة؟";
    } else if (currentSection === 'hadith' && (lowerMessage.includes('حديث') || lowerMessage.includes('رواية'))) {
        return "يمكنك البحث في الأحاديث أو تصفح المواضيع المختلفة في قسم الأحاديث. ما الذي تود معرفته؟";
    } else if (currentSection === 'prayer' && (lowerMessage.includes('وقت') || lowerMessage.includes('موعد'))) {
        return "يمكنك متابعة أوقات الصلاة في قسم أوقات الصلاة، حيث تُحدث تلقائياً حسب موقعك الجغرافي.";
    }

    // Default responses based on keywords
    if (lowerMessage.includes('السلام عليكم') || lowerMessage.includes('مرحبا')) {
        return 'وعليكم السلام ورحمة الله وبركاته! أهلاً وسهلاً بك في رفيق، رفيقك الإسلامي الشامل.';
    } else if (lowerMessage.includes('شكرا') || lowerMessage.includes('جزاك الله خير')) {
        return 'العفو، وإياك أخي الكريم. أسأل الله أن ينفع بك ويجعل ما قدمته في ميزان حسناتي.';
    } else if (lowerMessage.includes('دعاء') || lowerMessage.includes('أدعية')) {
        return 'يمكنك العثور على الأدعية المتنوعة في قسم الأدعية. هل تبحث عن دعاء محدد؟';
    } else if (lowerMessage.includes('ذكر') || lowerMessage.includes('أذكار')) {
        return 'الأذكار موجودة في قسم الأذكار، مقسمة حسب الأوقات (صباحية ومسائية). هل تريد تذكيراً محدداً؟';
    } else if (lowerMessage.includes('قبلة') || lowerMessage.includes('اتجاه')) {
        return 'يمكنك معرفة اتجاه القبلة بدقة في قسم القبلة، حيث يستخدم GPS لتحديد موقعك بدقة.';
    } else if (lowerMessage.includes('مسبحة') || lowerMessage.includes('تسبيح')) {
        return 'المسبحة الرقمية متوفرة في قسم المسبحة، مع عداد وحفظ للتاريخ والإنجازات.';
    } else if (lowerMessage.includes('رمضان') || lowerMessage.includes('صيام')) {
        return 'رمضان شهر الرحمة والمغفرة. يمكنك متابعة العد التنازلي في قسم التقويم الهجري.';
    } else if (lowerMessage.includes('عيد') || lowerMessage.includes('مبارك')) {
        return 'تقبل الله منا ومنكم صالح الأعمال. يمكنك متابعة التواريخ الهجرية في قسم التقويم.';
    } else if (lowerMessage.includes('مساعدة') || lowerMessage.includes('كيف')) {
        return 'يمكنني مساعدتك في: أوقات الصلاة، القرآن الكريم، الأحاديث، الأذكار، الأدعية، اتجاه القبلة، والمزيد. ما الذي تود معرفته؟';
    }

    // Fallback response
    return generateContextualResponse(message);
}

function generateContextualResponse(message) {
    // More intelligent fallback responses
    const responses = [
        'هذا سؤال ممتاز! يمكنني مساعدتك في فهم المزيد عن الإسلام. هل يمكنك توضيح سؤالك أكثر؟',
        'بارك الله فيك على سؤالك. يمكنك العثور على إجابة مفصلة في الأقسام المناسبة من التطبيق.',
        'سؤالك يستحق التأمل. دعني أفكر في أفضل طريقة لمساعدتك في هذا الموضوع.',
        'أشكرك على ثقتك بي. يمكنني إرشادك للمعلومات الصحيحة في هذا الموضوع.',
        'هذا موضوع مهم في الإسلام. يمكنك العثور على تفاصيل أكثر في قسم الأحاديث أو القرآن حسب الصلة.'
    ];

    return responses[Math.floor(Math.random() * responses.length)];
}

function buildAIKnowledgeBase() {
    // Build knowledge base from Quran, Hadiths, and other data
    aiKnowledgeBase = {};

    // Add Quran-related knowledge
    aiKnowledgeBase['ما هي سور القرآن؟'] = 'القرآن الكريم يحتوي على 114 سورة، تبدأ بسورة الفاتحة وتنتهي بسورة الناس.';
    aiKnowledgeBase['كم عدد آيات القرآن؟'] = 'القرآن الكريم يحتوي على 6236 آية.';
    aiKnowledgeBase['ما هي أطول سورة في القرآن؟'] = 'أطول سورة في القرآن هي سورة البقرة، وأقصرها هي سورة الكوثر.';

    // Add prayer-related knowledge
    aiKnowledgeBase['كم عدد الصلوات اليومية؟'] = 'الصلوات الخمس اليومية هي: الفجر، الظهر، العصر، المغرب، العشاء.';
    aiKnowledgeBase['ما هي شروط الصلاة؟'] = 'شروط الصلاة: الإسلام، العقل، البلوغ، الطهارة، دخول الوقت، ستر العورة، استقبال القبلة.';

    // Add Islamic knowledge
    aiKnowledgeBase['ما هي الشهادتان؟'] = 'الشهادتان هما: أشهد أن لا إله إلا الله وأشهد أن محمداً رسول الله.';
    aiKnowledgeBase['ما هي أسماء الله الحسنى؟'] = 'أسماء الله الحسنى 99 اسماً، منها: الرحمن، الرحيم، الملك، القدوس، السلام، المؤمن، المهيمن، العزيز، الجبار، المتكبر، الخالق، البارئ، المصور، الغفار، القهار، الوهاب، الرزاق، الفتاح، العليم، القابض، الباسط، الخافض، الرافع، المعز، المذل، السميع، البصير، الحكم، العدل، اللطيف، الخبير، الحليم، العظيم، الغفور، الشكور، العلي، الكبير، الحفيظ، المقيت، الحسيب، الجليل، الكريم، الرقيب، المجيب، الواسع، الحكيم، الودود، المجيد، الباعث، الشهيد، الحق، الوكيل، القوي، المتين، الولي، الحميد، المحصي، المبدئ، المعيد، المحيي، المميت، الحي، القيوم، الواجد، الماجد، الواحد، الصمد، القادر، المقتدر، المقدم، المؤخر، الأول، الآخر، الظاهر، الباطن، الوالي، المتعالي، البر، التواب، المنتقم، العفو، الرؤوف، مالك الملك، ذو الجلال والإكرام، المقسط، الجامع، الغني، المغني، المانع، الضار، النافع، النور، الهادي، البديع، الباقي، الوارث، الرشيد، الصبور.';

    // Add general Islamic knowledge
    aiKnowledgeBase['ما هي الكتب السماوية؟'] = 'الكتب السماوية هي: القرآن الكريم، التوراة، الإنجيل، الزبور، صحف إبراهيم وموسى.';
    aiKnowledgeBase['من هم الأنبياء؟'] = 'من الأنبياء: آدم، نوح، إبراهيم، موسى، عيسى، محمد صلى الله عليه وسلم، وغيرهم الكثير.';
}

function learnFromInteraction(userMessage, aiResponse) {
    // Simple learning mechanism - can be enhanced with more sophisticated algorithms
    const messageLower = userMessage.toLowerCase();

    // Track frequently asked questions
    if (!aiLearningData.questions) aiLearningData.questions = {};
    if (!aiLearningData.questions[messageLower]) {
        aiLearningData.questions[messageLower] = {
            count: 0,
            responses: []
        };
    }
    aiLearningData.questions[messageLower].count++;
    aiLearningData.questions[messageLower].responses.push(aiResponse);

    // Update knowledge base with successful responses
    if (messageLower.includes('ما هي') || messageLower.includes('كيف') || messageLower.includes('لماذا')) {
        if (!aiKnowledgeBase[userMessage]) {
            aiKnowledgeBase[userMessage] = aiResponse;
        }
    }
}

function saveChatData() {
    // Keep only last 100 messages to avoid storage overflow
    if (chatHistory.length > 100) {
        chatHistory = chatHistory.slice(-100);
    }

    localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
    localStorage.setItem('aiLearningData', JSON.stringify(aiLearningData));
}

function handleChatKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function askSuggestedQuestion(question) {
    document.getElementById('chat-input').value = question;
    sendMessage();
}

function clearChatHistory() {
    if (confirm('هل أنت متأكد من مسح سجل المحادثة؟')) {
        chatHistory = [];
        document.getElementById('chat-messages').innerHTML = '';
        localStorage.removeItem('chatHistory');
        showNotification('تم مسح المحادثة', 'تم حذف سجل المحادثة بنجاح');
    }
}

function exportChatHistory() {
    if (chatHistory.length === 0) {
        showNotification('لا توجد محادثات', 'لا يوجد سجل محادثة للتصدير');
        return;
    }

    const chatText = chatHistory.map(entry => {
        const date = new Date(entry.timestamp).toLocaleString('ar-SA');
        return `[${date}] ${entry.type === 'user' ? 'أنت' : 'رفيق'}: ${entry.message}`;
    }).join('\n');

    const blob = new Blob([chatText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `محادثة-رفيق-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);

    showNotification('تم تصدير المحادثة', 'تم حفظ سجل المحادثة في ملف نصي');
}

function getChatStatistics() {
    const userMessages = chatHistory.filter(entry => entry.type === 'user').length;
    const aiMessages = chatHistory.filter(entry => entry.type === 'ai').length;
    const uniqueQuestions = new Set(chatHistory.filter(entry => entry.type === 'user').map(entry => entry.message)).size;

    return {
        totalMessages: chatHistory.length,
        userMessages,
        aiMessages,
        uniqueQuestions,
        duration: chatHistory.length > 1 ? chatHistory[chatHistory.length - 1].timestamp - chatHistory[0].timestamp : 0
    };
}

function showChatStatistics() {
    const stats = getChatStatistics();
    const duration = Math.floor(stats.duration / (1000 * 60)); // minutes

    return `
        <div class="chat-stats">
            <h4>إحصائيات المحادثة</h4>
            <p>إجمالي الرسائل: ${stats.totalMessages}</p>
            <p>رسائلك: ${stats.userMessages}</p>
            <p>ردود رفيق: ${stats.aiMessages}</p>
            <p>الأسئلة الفريدة: ${stats.uniqueQuestions}</p>
            <p>مدة المحادثة: ${duration} دقيقة</p>
        </div>
    `;
}

// Initialize AI when page loads
document.addEventListener('DOMContentLoaded', () => {
    // ... existing initialization code ...
    initializeAI();
});

// Navigation
function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => section.classList.remove('active'));
    document.getElementById(sectionId).classList.add('active');
}

// Prayer Times
async function fetchPrayerTimes() {
    const latitude = 41.0082; // Istanbul
    const longitude = 28.9784;
    const response = await fetch(`https://api.aladhan.com/v1/timings?latitude=${latitude}&longitude=${longitude}&method=2`);
    const data = await response.json();
    prayerTimes = data.data.timings;
    displayPrayerTimes();
    updateCountdown();
}

function displayPrayerTimes() {
    const container = document.getElementById('prayer-times');
    container.innerHTML = `
        <p>الفجر: ${prayerTimes.Fajr} <button onclick="markPrayer('fajr')">تم</button></p>
        <p>الظهر: ${prayerTimes.Dhuhr} <button onclick="markPrayer('dhuhr')">تم</button></p>
        <p>العصر: ${prayerTimes.Asr} <button onclick="markPrayer('asr')">تم</button></p>
        <p>المغرب: ${prayerTimes.Maghrib} <button onclick="markPrayer('maghrib')">تم</button></p>
        <p>العشاء: ${prayerTimes.Isha} <button onclick="markPrayer('isha')">تم</button></p>
    `;
    updatePrayerStats();
}

function updateCountdown() {
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    const prayers = [
        { name: 'الفجر', time: prayerTimes.Fajr },
        { name: 'الظهر', time: prayerTimes.Dhuhr },
        { name: 'العصر', time: prayerTimes.Asr },
        { name: 'المغرب', time: prayerTimes.Maghrib },
        { name: 'العشاء', time: prayerTimes.Isha }
    ];

    let nextPrayer = null;
    for (let prayer of prayers) {
        const [hours, minutes] = prayer.time.split(':').map(Number);
        const prayerTime = hours * 60 + minutes;
        if (prayerTime > currentTime) {
            nextPrayer = prayer;
            break;
        }
    }

    if (!nextPrayer) nextPrayer = prayers[0]; // Next day Fajr

    const [hours, minutes] = nextPrayer.time.split(':').map(Number);
    const prayerTime = hours * 60 + minutes;
    let remaining = prayerTime - currentTime;
    if (remaining < 0) remaining += 24 * 60; // Next day

    const hoursLeft = Math.floor(remaining / 60);
    const minutesLeft = remaining % 60;

    document.getElementById('countdown').innerHTML = `باقي على ${nextPrayer.name}: ${hoursLeft} ساعة و ${minutesLeft} دقيقة`;

    // Reminder 10 minutes before
    if (remaining <= 10 && remaining > 0) {
        speak(`صلاة ${nextPrayer.name} بعد قليل`);
    }
}

let remindersEnabled = false;
let prayerStats = JSON.parse(localStorage.getItem('prayerStats')) || { fajr: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 };

function togglePrayerReminders() {
    remindersEnabled = !remindersEnabled;
    const button = document.querySelector('#prayer button');
    button.textContent = remindersEnabled ? 'تعطيل التذكيرات' : 'تفعيل التذكيرات';
    if (remindersEnabled) {
        if (Notification.permission === 'default') {
            Notification.requestPermission();
        }
    }
}

function checkReminders() {
    if (!remindersEnabled) return;
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    const prayers = [
        { name: 'الفجر', time: prayerTimes.Fajr },
        { name: 'الظهر', time: prayerTimes.Dhuhr },
        { name: 'العصر', time: prayerTimes.Asr },
        { name: 'المغرب', time: prayerTimes.Maghrib },
        { name: 'العشاء', time: prayerTimes.Isha }
    ];

    for (let prayer of prayers) {
        const [hours, minutes] = prayer.time.split(':').map(Number);
        const prayerTime = hours * 60 + minutes;
        const remaining = prayerTime - currentTime;
        if (remaining === 10) {
            new Notification(`تذكير: صلاة ${prayer.name} بعد 10 دقائق`);
            speak(`صلاة ${prayer.name} بعد قليل`);
        }
    }
}

function speak(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(utterance);
}

function markPrayer(prayer) {
    prayerStats[prayer]++;
    localStorage.setItem('prayerStats', JSON.stringify(prayerStats));
    updatePrayerStats();
}

function updatePrayerStats() {
    const stats = document.getElementById('prayer-stats');
    stats.innerHTML = `
        <h3>إحصائيات الصلاة</h3>
        <p>الفجر: ${prayerStats.fajr}</p>
        <p>الظهر: ${prayerStats.dhuhr}</p>
        <p>العصر: ${prayerStats.asr}</p>
        <p>المغرب: ${prayerStats.maghrib}</p>
        <p>العشاء: ${prayerStats.isha}</p>
    `;
}

// Theme and Language Functions
function toggleTheme() {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', currentTheme);
    localStorage.setItem('theme', currentTheme);

    const themeButton = document.getElementById('theme-toggle');
    if (currentTheme === 'dark') {
        themeButton.innerHTML = '☀️ الوضع النهاري';
    } else {
        themeButton.innerHTML = '🌙 الوضع الليلي';
    }
}

function changeLanguage() {
    const languageSelect = document.getElementById('language-select');
    currentLanguage = languageSelect.value;
    localStorage.setItem('language', currentLanguage);

    // Update page content based on language
    updateLanguageContent();
}

function updateLanguageContent() {
    const content = {
        ar: {
            title: 'رفيق - رفيقك الإسلامي',
            subtitle: 'رفيقك الإسلامي الشامل',
            prayer: 'أوقات الصلاة',
            quran: 'القرآن الكريم',
            calendar: 'التقويم الهجري',
            hadith: 'الأحاديث',
            dhikr: 'الأذكار',
            dua: 'الأدعية',
            qibla: 'القبلة',
            tasbih: 'المسبحة',
            ai: 'الذكاء الاصطناعي'
        },
        en: {
            title: 'Rafeeq - Your Islamic Companion',
            subtitle: 'Your Comprehensive Islamic Companion',
            prayer: 'Prayer Times',
            quran: 'Quran',
            calendar: 'Hijri Calendar',
            hadith: 'Hadiths',
            dhikr: 'Dhikr',
            dua: 'Duas',
            qibla: 'Qibla',
            tasbih: 'Tasbih',
            ai: 'AI Assistant'
        }
    };

    const lang = content[currentLanguage];
    if (lang) {
        document.title = lang.title;
        document.querySelector('header h1').textContent = currentLanguage === 'ar' ? 'رفيق' : 'Rafeeq';
        document.querySelector('header p').textContent = lang.subtitle;

        // Update navigation buttons
        const navButtons = document.querySelectorAll('nav button');
        navButtons[0].textContent = lang.prayer;
        navButtons[1].textContent = lang.quran;
        navButtons[2].textContent = lang.calendar;
        navButtons[3].textContent = lang.hadith;
        navButtons[4].textContent = lang.dhikr;
        navButtons[5].textContent = lang.dua;
        navButtons[6].textContent = lang.qibla;
        navButtons[7].textContent = lang.tasbih;
        navButtons[8].textContent = lang.ai;

        // Update section headings
        const sections = document.querySelectorAll('.section h2');
        sections[0].textContent = lang.prayer;
        sections[1].textContent = lang.quran;
        sections[2].textContent = lang.calendar;
        sections[3].textContent = lang.hadith;
        sections[4].textContent = lang.dhikr;
        sections[5].textContent = lang.dua;
        sections[6].textContent = lang.qibla;
        sections[7].textContent = lang.tasbih;
        sections[8].textContent = lang.ai;
    }
}

function updateReminderTime() {
    const select = document.getElementById('reminder-time');
    notificationSettings.reminderTime = parseInt(select.value);
    localStorage.setItem('notificationSettings', JSON.stringify(notificationSettings));

    if (notificationSettings.enabled) {
        schedulePrayerNotifications();
        showNotification('تم تحديث وقت التذكير', `سيتم تذكيرك قبل ${notificationSettings.reminderTime} دقيقة من كل صلاة`);
    }
}

function updateNotificationSettings() {
    const soundCheckbox = document.getElementById('sound-enabled');
    const vibrationCheckbox = document.getElementById('vibration-enabled');

    notificationSettings.soundEnabled = soundCheckbox.checked;
    notificationSettings.vibrationEnabled = vibrationCheckbox.checked;

    localStorage.setItem('notificationSettings', JSON.stringify(notificationSettings));
}

function updatePrayerSettings() {
    const checkboxes = document.querySelectorAll('.prayer-settings input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
        const prayer = checkbox.dataset.prayer;
        notificationSettings.prayers[prayer] = checkbox.checked;
    });

    localStorage.setItem('notificationSettings', JSON.stringify(notificationSettings));

    if (notificationSettings.enabled) {
        schedulePrayerNotifications();
        showNotification('تم تحديث إعدادات الصلوات', 'سيتم تطبيق الإعدادات الجديدة على التذكيرات القادمة');
    }
}

let backupSettings = JSON.parse(localStorage.getItem('backupSettings')) || {
    autoBackup: true,
    backupFrequency: 'weekly',
    encryptBackup: true,
    lastBackup: null,
    cloudSync: false
};

function exportData() {
    const data = {
        bookmarks,
        khatmaProgress,
        tasbihHistory,
        prayerStats,
        notificationSettings,
        appSettings,
        theme: currentTheme,
        language: currentLanguage,
        chatHistory,
        searchHistory,
        lastReadPosition,
        exportDate: new Date().toISOString(),
        version: '2.0'
    };

    let exportContent = JSON.stringify(data, null, 2);
    let filename = 'rafiq-backup.json';
    let mimeType = 'application/json';

    if (backupSettings.encryptBackup) {
        exportContent = encryptData(exportContent);
        filename = 'rafiq-backup.rafiq';
        mimeType = 'application/octet-stream';
    }

    const blob = new Blob([exportContent], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);

    // Update backup status
    updateBackupStatus();
    showNotification('تم تصدير البيانات', 'تم حفظ البيانات في ملف النسخة الاحتياطية');
}

function createBackup() {
    exportData();
}

function importData() {
    const fileInput = document.getElementById('import-file');
    fileInput.click();

    fileInput.onchange = function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    let data = e.target.result;

                    // Check if file is encrypted
                    if (file.name.endsWith('.rafiq')) {
                        const password = prompt('أدخل كلمة المرور لفك التشفير:');
                        if (password) {
                            data = decryptData(data, password);
                        } else {
                            showNotification('خطأ في الاستيراد', 'كلمة المرور مطلوبة للملفات المشفرة');
                            return;
                        }
                    }

                    data = JSON.parse(data);

                    if (confirm('هل أنت متأكد من استيراد البيانات؟ ستحل محل البيانات الحالية.')) {
                        restoreData(data);
                        showNotification('تم استيراد البيانات', 'تم استعادة البيانات بنجاح');
                    }
                } catch (error) {
                    showNotification('خطأ في استيراد البيانات', 'الملف تالف أو كلمة المرور خاطئة');
                }
            };

            if (file.name.endsWith('.rafiq')) {
                reader.readAsText(file);
            } else {
                reader.readAsText(file);
            }
        }
    };
}

function restoreData(data) {
    // Restore all data
    if (data.bookmarks) bookmarks = data.bookmarks;
    if (data.khatmaProgress) khatmaProgress = data.khatmaProgress;
    if (data.tasbihHistory) tasbihHistory = data.tasbihHistory;
    if (data.prayerStats) prayerStats = data.prayerStats;
    if (data.notificationSettings) notificationSettings = data.notificationSettings;
    if (data.appSettings) appSettings = data.appSettings;
    if (data.theme) currentTheme = data.theme;
    if (data.language) currentLanguage = data.language;
    if (data.chatHistory) chatHistory = data.chatHistory;
    if (data.searchHistory) searchHistory = data.searchHistory;
    if (data.lastReadPosition) lastReadPosition = data.lastReadPosition;

    // Save all data
    saveAllData();

    // Apply settings
    applySavedSettings();

    // Update UI
    updateTasbihHistory();
    updatePrayerStats();
    updateNotificationButton();
}

function saveAllData() {
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    localStorage.setItem('khatmaProgress', JSON.stringify(khatmaProgress));
    localStorage.setItem('tasbihHistory', JSON.stringify(tasbihHistory));
    localStorage.setItem('prayerStats', JSON.stringify(prayerStats));
    localStorage.setItem('notificationSettings', JSON.stringify(notificationSettings));
    localStorage.setItem('appSettings', JSON.stringify(appSettings));
    localStorage.setItem('theme', currentTheme);
    localStorage.setItem('language', currentLanguage);
    localStorage.setItem('chatHistory', JSON.stringify(chatHistory));
    localStorage.setItem('searchHistory', JSON.stringify(searchHistory));
    localStorage.setItem('lastReadPosition', JSON.stringify(lastReadPosition));
}

function encryptData(data) {
    // Simple encryption for demo - in production use proper encryption
    const password = 'rafiq_backup_key_2024';
    let encrypted = '';
    for (let i = 0; i < data.length; i++) {
        encrypted += String.fromCharCode(data.charCodeAt(i) ^ password.charCodeAt(i % password.length));
    }
    return btoa(encrypted);
}

function decryptData(encryptedData, password) {
    try {
        const data = atob(encryptedData);
        const key = password || 'rafiq_backup_key_2024';
        let decrypted = '';
        for (let i = 0; i < data.length; i++) {
            decrypted += String.fromCharCode(data.charCodeAt(i) ^ key.charCodeAt(i % key.length));
        }
        return decrypted;
    } catch (error) {
        throw new Error('فشل في فك التشفير');
    }
}

function updateBackupSettings() {
    const autoBackupCheckbox = document.getElementById('auto-backup');
    const frequencySelect = document.getElementById('backup-frequency');
    const encryptCheckbox = document.getElementById('encrypt-backup');

    backupSettings.autoBackup = autoBackupCheckbox.checked;
    backupSettings.backupFrequency = frequencySelect.value;
    backupSettings.encryptBackup = encryptCheckbox.checked;

    localStorage.setItem('backupSettings', JSON.stringify(backupSettings));

    if (backupSettings.autoBackup) {
        scheduleAutoBackup();
        showNotification('تم تفعيل النسخ الاحتياطي التلقائي', `سيتم إنشاء نسخة احتياطية ${backupSettings.backupFrequency}`);
    }
}

function scheduleAutoBackup() {
    if (!backupSettings.autoBackup) return;

    const now = new Date();
    const intervals = {
        daily: 24 * 60 * 60 * 1000,     // 24 hours
        weekly: 7 * 24 * 60 * 60 * 1000, // 7 days
        monthly: 30 * 24 * 60 * 60 * 1000 // 30 days
    };

    const nextBackup = new Date(now.getTime() + intervals[backupSettings.backupFrequency]);

    // In a real app, you'd use more sophisticated scheduling
    setTimeout(() => {
        createAutoBackup();
        scheduleAutoBackup(); // Schedule next backup
    }, intervals[backupSettings.backupFrequency]);
}

function createAutoBackup() {
    const data = {
        bookmarks,
        khatmaProgress,
        tasbihHistory,
        prayerStats,
        notificationSettings,
        appSettings,
        theme: currentTheme,
        language: currentLanguage,
        chatHistory,
        searchHistory,
        lastReadPosition,
        exportDate: new Date().toISOString(),
        version: '2.0',
        type: 'auto'
    };

    let backupContent = JSON.stringify(data, null, 2);
    if (backupSettings.encryptBackup) {
        backupContent = encryptData(backupContent);
    }

    localStorage.setItem('autoBackup', backupContent);
    localStorage.setItem('lastAutoBackup', new Date().toISOString());

    updateBackupStatus();
    console.log('Auto backup created');
}

function updateBackupStatus() {
    const statusElement = document.getElementById('backup-status');
    const lastBackup = localStorage.getItem('lastAutoBackup');

    if (lastBackup) {
        const date = new Date(lastBackup).toLocaleString('ar-SA');
        statusElement.textContent = `آخر نسخة احتياطية: ${date}`;
    } else {
        statusElement.textContent = 'آخر نسخة احتياطية: لم يتم بعد';
    }
}

function restoreFromCloud() {
    showNotification('خدمة السحابة', 'خدمة المزامنة السحابية ستكون متاحة قريباً');
}

function initializeBackupSystem() {
    // Apply backup settings to form
    document.getElementById('auto-backup').checked = backupSettings.autoBackup;
    document.getElementById('backup-frequency').value = backupSettings.backupFrequency;
    document.getElementById('encrypt-backup').checked = backupSettings.encryptBackup;

    // Update backup status
    updateBackupStatus();

    // Schedule auto backup if enabled
    if (backupSettings.autoBackup) {
        scheduleAutoBackup();
    }
}

function initializeAppTesting() {
    // Browser compatibility check
    checkBrowserCompatibility();

    // Performance monitoring
    monitorPerformance();

    // Memory usage tracking
    trackMemoryUsage();

    // Network monitoring
    monitorNetworkQuality();

    // Run automated tests
    runAutomatedTests();
}

function checkBrowserCompatibility() {
    const compatibility = {
        serviceWorker: 'serviceWorker' in navigator,
        notifications: 'Notification' in window,
        geolocation: 'geolocation' in navigator,
        localStorage: 'localStorage' in window,
        indexedDB: 'indexedDB' in window,
        webWorkers: 'Worker' in window,
        fetch: 'fetch' in window,
        promises: 'Promise' in window,
        asyncAwait: true // Most modern browsers support this
    };

    // Store compatibility info
    localStorage.setItem('browserCompatibility', JSON.stringify(compatibility));

    // Show warnings for missing features
    const warnings = [];
    if (!compatibility.serviceWorker) warnings.push('Service Worker غير مدعوم');
    if (!compatibility.notifications) warnings.push('الإشعارات غير مدعومة');
    if (!compatibility.geolocation) warnings.push('تحديد الموقع غير مدعوم');

    if (warnings.length > 0) {
        console.warn('Browser Compatibility Issues:', warnings);
        // Show user-friendly warning in UI
        showCompatibilityWarning(warnings);
    }
}

function showCompatibilityWarning(warnings) {
    const warningDiv = document.createElement('div');
    warningDiv.className = 'compatibility-warning';
    warningDiv.innerHTML = `
        <div class="warning-content">
            <h4>⚠️ تنبيه التوافق</h4>
            <p>بعض الميزات قد لا تعمل بشكل صحيح:</p>
            <ul>
                ${warnings.map(warning => `<li>${warning}</li>`).join('')}
            </ul>
            <p>ننصح باستخدام أحدث إصدار من المتصفح</p>
        </div>
    `;

    // Add styles
    warningDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #fef3c7;
        border: 1px solid #f59e0b;
        border-radius: 10px;
        padding: 1rem;
        max-width: 300px;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;

    document.body.appendChild(warningDiv);

    // Auto-hide after 10 seconds
    setTimeout(() => {
        if (warningDiv.parentNode) {
            warningDiv.remove();
        }
    }, 10000);
}

function monitorPerformance() {
    // Monitor page load performance
    if ('performance' in window) {
        window.addEventListener('load', () => {
            setTimeout(() => {
                const perfData = performance.getEntriesByType('navigation')[0];
                const loadTime = perfData.loadEventEnd - perfData.loadEventStart;
                const domContentLoaded = perfData.domContentLoadedEventEnd - perfData.domContentLoadedEventStart;

                console.log('Performance Metrics:', {
                    loadTime: `${loadTime}ms`,
                    domContentLoaded: `${domContentLoaded}ms`,
                    firstPaint: getFirstPaintTime()
                });

                // Store performance metrics
                localStorage.setItem('lastLoadTime', loadTime);
                localStorage.setItem('lastDOMContentLoaded', domContentLoaded);
            }, 0);
        });
    }
}

function getFirstPaintTime() {
    if ('performance' in window) {
        const paintEntries = performance.getEntriesByType('paint');
        const firstPaint = paintEntries.find(entry => entry.name === 'first-paint');
        return firstPaint ? `${firstPaint.startTime.toFixed(2)}ms` : 'Not available';
    }
    return 'Not supported';
}

function trackMemoryUsage() {
    if ('memory' in performance) {
        setInterval(() => {
            const memory = performance.memory;
            const usage = {
                used: Math.round(memory.usedJSHeapSize / 1048576), // Convert to MB
                total: Math.round(memory.totalJSHeapSize / 1048576),
                limit: Math.round(memory.jsHeapSizeLimit / 1048576)
            };

            // Log if memory usage is high
            if (usage.used > 50) { // More than 50MB
                console.warn('High memory usage:', usage);
            }

            localStorage.setItem('memoryUsage', JSON.stringify(usage));
        }, 30000); // Check every 30 seconds
    }
}

function monitorNetworkQuality() {
    let connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;

    if (connection) {
        const updateConnectionStatus = () => {
            const networkInfo = {
                effectiveType: connection.effectiveType,
                downlink: connection.downlink,
                rtt: connection.rtt,
                saveData: connection.saveData
            };

            localStorage.setItem('networkInfo', JSON.stringify(networkInfo));

            // Adjust app behavior based on network quality
            if (networkInfo.effectiveType === 'slow-2g' || networkInfo.effectiveType === '2g') {
                // Reduce data usage for slow connections
                document.body.classList.add('slow-connection');
            } else {
                document.body.classList.remove('slow-connection');
            }
        };

        connection.addEventListener('change', updateConnectionStatus);
        updateConnectionStatus();
    }
}

function runAutomatedTests() {
    // Run basic functionality tests
    setTimeout(() => {
        const testResults = {
            localStorage: testLocalStorage(),
            geolocation: testGeolocation(),
            notifications: testNotifications(),
            audio: testAudio(),
            quranAPI: testQuranAPI(),
            prayerAPI: testPrayerAPI()
        };

        console.log('Automated Test Results:', testResults);
        localStorage.setItem('lastTestResults', JSON.stringify(testResults));

        // Show test results in UI if there are failures
        const failures = Object.entries(testResults).filter(([test, result]) => !result).map(([test]) => test);
        if (failures.length > 0) {
            showTestWarning(failures);
        }
    }, 2000);
}

function testLocalStorage() {
    try {
        localStorage.setItem('test', 'test');
        localStorage.removeItem('test');
        return true;
    } catch (e) {
        return false;
    }
}

function testGeolocation() {
    return 'geolocation' in navigator;
}

function testNotifications() {
    return 'Notification' in window;
}

function testAudio() {
    return 'Audio' in window;
}

function testQuranAPI() {
    // Test if we can reach Quran API
    return fetch('https://api.quran.com/api/v4/chapters/1')
        .then(response => response.ok)
        .catch(() => false);
}

function testPrayerAPI() {
    // Test if we can reach Prayer Times API
    return fetch('https://api.aladhan.com/v1/timings?latitude=21.4225&longitude=39.8262')
        .then(response => response.ok)
        .catch(() => false);
}

function showTestWarning(failures) {
    const warningDiv = document.createElement('div');
    warningDiv.className = 'test-warning';
    warningDiv.innerHTML = `
        <div class="warning-content">
            <h4>🔧 مشاكل في الاختبار</h4>
            <p>بعض الوظائف قد لا تعمل بشكل صحيح:</p>
            <ul>
                ${failures.map(failure => `<li>${getTestDescription(failure)}</li>`).join('')}
            </ul>
        </div>
    `;

    warningDiv.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 20px;
        background: #fee2e2;
        border: 1px solid #dc2626;
        border-radius: 10px;
        padding: 1rem;
        max-width: 300px;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;

    document.body.appendChild(warningDiv);

    setTimeout(() => {
        if (warningDiv.parentNode) {
            warningDiv.remove();
        }
    }, 15000);
}

function getTestDescription(test) {
    const descriptions = {
        localStorage: 'حفظ البيانات محلياً',
        geolocation: 'تحديد الموقع الجغرافي',
        notifications: 'الإشعارات',
        audio: 'تشغيل الصوت',
        quranAPI: 'تحميل بيانات القرآن',
        prayerAPI: 'تحميل أوقات الصلاة'
    };
    return descriptions[test] || test;
}

function initializeErrorHandling() {
    // Global error handler
    window.addEventListener('error', (event) => {
        console.error('Global error:', event.error);
        logError('JavaScript Error', event.error, event.filename, event.lineno);
    });

    // Promise rejection handler
    window.addEventListener('unhandledrejection', (event) => {
        console.error('Unhandled promise rejection:', event.reason);
        logError('Promise Rejection', event.reason);
    });

    // API error handler
    window.addEventListener('offline', () => {
        logError('Network Error', 'Connection lost');
    });
}

function logError(type, error, filename = '', lineno = '') {
    const errorLog = {
        type,
        error: error.toString(),
        filename,
        lineno,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        url: window.location.href
    };

    // Store error log (keep only last 50 errors)
    const existingLogs = JSON.parse(localStorage.getItem('errorLogs') || '[]');
    existingLogs.unshift(errorLog);
    if (existingLogs.length > 50) {
        existingLogs.pop();
    }
    localStorage.setItem('errorLogs', JSON.stringify(existingLogs));

    // Send error report (in production, send to error reporting service)
    if (appSettings.analyticsEnabled) {
        console.log('Error logged:', errorLog);
    }
}

function showAppInfo() {
    const info = {
        version: '2.0.0',
        buildDate: new Date().toISOString(),
        browser: navigator.userAgent,
        screen: `${screen.width}x${screen.height}`,
        language: navigator.language,
        platform: navigator.platform,
        cookies: navigator.cookieEnabled,
        online: navigator.onLine
    };

    const modal = createModal(`
        <h3>معلومات التطبيق</h3>
        <div class="app-info">
            ${Object.entries(info).map(([key, value]) =>
                `<div class="info-item"><strong>${key}:</strong> ${value}</div>`
            ).join('')}
        </div>
        <div class="info-buttons">
            <button onclick="runManualTests()">تشغيل الاختبارات</button>
            <button onclick="showErrorLogs()">عرض سجل الأخطاء</button>
            <button onclick="clearErrorLogs()">مسح سجل الأخطاء</button>
        </div>
    `);
}

function runManualTests() {
    closeModal();
    runAutomatedTests();
    setTimeout(() => {
        showNotification('تم تشغيل الاختبارات', 'اكتملت الاختبارات، تحقق من وحدة التحكم');
    }, 3000);
}

function showErrorLogs() {
    const errorLogs = JSON.parse(localStorage.getItem('errorLogs') || '[]');
    const modal = createModal(`
        <h3>سجل الأخطاء (${errorLogs.length})</h3>
        <div class="error-logs">
            ${errorLogs.slice(0, 10).map(log => `
                <div class="error-item">
                    <div class="error-time">${new Date(log.timestamp).toLocaleString('ar-SA')}</div>
                    <div class="error-type">${log.type}</div>
                    <div class="error-message">${log.error}</div>
                </div>
            `).join('')}
        </div>
    `);
}

function clearErrorLogs() {
    localStorage.removeItem('errorLogs');
    showNotification('تم مسح السجل', 'تم حذف سجل الأخطاء');
}

function importData() {
    const fileInput = document.getElementById('import-file');
    fileInput.click();

    fileInput.onchange = function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const data = JSON.parse(e.target.result);

                    if (confirm('هل أنت متأكد من استيراد البيانات؟ ستحل محل البيانات الحالية.')) {
                        bookmarks = data.bookmarks || [];
                        khatmaProgress = data.khatmaProgress || { current: 0, total: 604 };
                        tasbihHistory = data.tasbihHistory || [];
                        prayerStats = data.prayerStats || { fajr: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 };
                        notificationSettings = data.notificationSettings || notificationSettings;
                        currentTheme = data.theme || 'light';
                        currentLanguage = data.language || 'ar';

                        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
                        localStorage.setItem('khatmaProgress', JSON.stringify(khatmaProgress));
                        localStorage.setItem('tasbihHistory', JSON.stringify(tasbihHistory));
                        localStorage.setItem('prayerStats', JSON.stringify(prayerStats));
                        localStorage.setItem('notificationSettings', JSON.stringify(notificationSettings));
                        localStorage.setItem('theme', currentTheme);
                        localStorage.setItem('language', currentLanguage);

                        applySavedSettings();
                        updateNotificationButton();

                        if (notificationSettings.enabled) {
                            schedulePrayerNotifications();
                        }

                        showNotification('تم استيراد البيانات', 'تم استعادة البيانات بنجاح');
                    }
                } catch (error) {
                    showNotification('خطأ في استيراد البيانات', 'الملف تالف أو غير صالح');
                }
            };
            reader.readAsText(file);
        }
    };
}

function resetData() {
    if (confirm('هل أنت متأكد من حذف جميع البيانات؟ هذا الإجراء لا يمكن التراجع عنه.')) {
        bookmarks = [];
        khatmaProgress = { current: 0, total: 604 };
        tasbihHistory = [];
        prayerStats = { fajr: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 };
        tasbihCount = 0;

        localStorage.removeItem('bookmarks');
        localStorage.removeItem('khatmaProgress');
        localStorage.removeItem('tasbihHistory');
        localStorage.removeItem('prayerStats');

        document.getElementById('tasbih-counter').innerHTML = '0';
        updateTasbihHistory();
        updatePrayerStats();

        showNotification('تم حذف البيانات', 'تم حذف جميع البيانات المحفوظة');
    }
}

// Advanced Settings Functions
function updateFontSize() {
    const select = document.getElementById('font-size');
    appSettings.fontSize = select.value;
    applyFontSettings();
    localStorage.setItem('appSettings', JSON.stringify(appSettings));
}

function updateFontFamily() {
    const select = document.getElementById('font-family');
    appSettings.fontFamily = select.value;
    applyFontSettings();
    localStorage.setItem('appSettings', JSON.stringify(appSettings));
}

function updatePrimaryColor() {
    const colorInput = document.getElementById('primary-color');
    appSettings.primaryColor = colorInput.value;
    applyColorSettings();
    localStorage.setItem('appSettings', JSON.stringify(appSettings));
}

function updateAnimationSpeed() {
    const select = document.getElementById('animation-speed');
    appSettings.animationSpeed = select.value;
    applyAnimationSettings();
    localStorage.setItem('appSettings', JSON.stringify(appSettings));
}

function updateAudioSettings() {
    const autoPlayCheckbox = document.getElementById('auto-play-audio');
    const qualitySelect = document.getElementById('audio-quality');
    const soundCheckbox = document.getElementById('notification-sound');

    appSettings.autoPlayAudio = autoPlayCheckbox.checked;
    appSettings.audioQuality = qualitySelect.value;
    appSettings.notificationSound = soundCheckbox.checked;

    localStorage.setItem('appSettings', JSON.stringify(appSettings));
}

function updateVolume() {
    const volumeControl = document.getElementById('volume-control');
    appSettings.volume = volumeControl.value;

    // Apply volume to audio elements
    if (audioPlayer) {
        audioPlayer.volume = appSettings.volume / 100;
    }

    localStorage.setItem('appSettings', JSON.stringify(appSettings));
}

function updatePrivacySettings() {
    const searchHistoryCheckbox = document.getElementById('save-search-history');
    const analyticsCheckbox = document.getElementById('analytics-enabled');
    const privacyCheckbox = document.getElementById('privacy-mode');

    appSettings.saveSearchHistory = searchHistoryCheckbox.checked;
    appSettings.analyticsEnabled = analyticsCheckbox.checked;
    appSettings.privacyMode = privacyCheckbox.checked;

    localStorage.setItem('appSettings', JSON.stringify(appSettings));

    if (appSettings.privacyMode) {
        // Disable analytics and clear sensitive data
        clearSensitiveData();
    }
}

function updatePerformanceSettings() {
    const powerSavingCheckbox = document.getElementById('power-saving');
    const autoUpdateCheckbox = document.getElementById('auto-update');
    const cacheSelect = document.getElementById('cache-size');

    appSettings.powerSaving = powerSavingCheckbox.checked;
    appSettings.autoUpdate = autoUpdateCheckbox.checked;
    appSettings.cacheSize = cacheSelect.value;

    applyPerformanceSettings();
    localStorage.setItem('appSettings', JSON.stringify(appSettings));
}

function applyFontSettings() {
    const fontSizes = {
        small: '14px',
        medium: '16px',
        large: '18px',
        xlarge: '20px'
    };

    const fontFamilies = {
        cairo: "'Cairo', 'Segoe UI', Tahoma, Arial, sans-serif",
        tajawal: "'Tajawal', 'Segoe UI', Tahoma, Arial, sans-serif",
        amiri: "'Amiri', 'Times New Roman', serif",
        naskh: "'Noto Naskh Arabic', 'Times New Roman', serif"
    };

    document.documentElement.style.fontSize = fontSizes[appSettings.fontSize];
    document.body.style.fontFamily = fontFamilies[appSettings.fontFamily];

    // Load Google Fonts if needed
    loadGoogleFont(appSettings.fontFamily);
}

function applyColorSettings() {
    document.documentElement.style.setProperty('--primary-color', appSettings.primaryColor);
    document.documentElement.style.setProperty('--button-background', `linear-gradient(45deg, ${appSettings.primaryColor}, #764ba2)`);
}

function applyAnimationSettings() {
    const animationSpeeds = {
        none: '0s',
        slow: '0.5s',
        normal: '0.3s',
        fast: '0.15s'
    };

    document.documentElement.style.setProperty('--animation-duration', animationSpeeds[appSettings.animationSpeed]);

    // Apply transition duration to all elements
    const style = document.createElement('style');
    style.textContent = `
        * {
            transition-duration: ${animationSpeeds[appSettings.animationSpeed]} !important;
        }
    `;
    document.head.appendChild(style);
}

function applyPerformanceSettings() {
    if (appSettings.powerSaving) {
        // Disable animations and reduce update frequency
        document.body.classList.add('power-saving');
        clearInterval(window.prayerUpdateInterval);
        window.prayerUpdateInterval = setInterval(() => {
            updateCountdown();
            checkReminders();
        }, 120000); // Update every 2 minutes instead of 1
    } else {
        document.body.classList.remove('power-saving');
        clearInterval(window.prayerUpdateInterval);
        window.prayerUpdateInterval = setInterval(() => {
            updateCountdown();
            checkReminders();
        }, 60000); // Update every minute
    }

    // Update cache settings
    updateCacheSettings();
}

function loadGoogleFont(fontFamily) {
    const fontLinks = {
        cairo: 'https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap',
        tajawal: 'https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800&display=swap',
        amiri: 'https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&display=swap',
        naskh: 'https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400;500;600;700&display=swap'
    };

    if (fontLinks[fontFamily]) {
        let link = document.querySelector(`link[href="${fontLinks[fontFamily]}"]`);
        if (!link) {
            link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = fontLinks[fontFamily];
            document.head.appendChild(link);
        }
    }
}

function clearCache() {
    if ('caches' in window) {
        caches.keys().then(names => {
            names.forEach(name => {
                caches.delete(name);
            });
        });
    }

    // Clear app cache
    localStorage.removeItem('quranCache');
    localStorage.removeItem('hadithCache');

    updateCacheSizeDisplay();
    showNotification('تم مسح ذاكرة التخزين المؤقت', 'تم حذف جميع الملفات المؤقتة');
}

function updateCacheSizeDisplay() {
    const sizeDisplay = document.getElementById('cache-size-display');
    let size = 0;

    // Calculate approximate cache size
    for (let key in localStorage) {
        if (key.includes('Cache') || key.includes('cache')) {
            size += localStorage.getItem(key).length;
        }
    }

    sizeDisplay.textContent = `${Math.round(size / 1024)} KB`;
}

function clearSensitiveData() {
    searchHistory = [];
    chatHistory = [];
    localStorage.removeItem('searchHistory');
    localStorage.removeItem('chatHistory');
    showNotification('تم مسح البيانات الحساسة', 'تم حذف بيانات البحث والمحادثات');
}

function clearAllData() {
    if (confirm('هل أنت متأكد من مسح جميع البيانات الشخصية؟ هذا يشمل الإشارات المرجعية والتقدم والإعدادات.')) {
        clearSensitiveData();
        resetData();
        showNotification('تم مسح جميع البيانات', 'تم حذف جميع البيانات الشخصية والإعدادات');
    }
}

function showDataUsage() {
    const dataUsage = calculateDataUsage();
    const modal = createModal(`
        <h3>استخدام البيانات والتخزين</h3>
        <div class="data-usage">
            <div class="usage-item">
                <strong>البيانات المحفوظة:</strong> ${dataUsage.localStorage} KB
            </div>
            <div class="usage-item">
                <strong>الإشارات المرجعية:</strong> ${dataUsage.bookmarks} عنصر
            </div>
            <div class="usage-item">
                <strong>سجل التسبيح:</strong> ${dataUsage.tasbihHistory} جلسة
            </div>
            <div class="usage-item">
                <strong>سجل المحادثات:</strong> ${dataUsage.chatHistory} رسالة
            </div>
            <div class="usage-item">
                <strong>الإعدادات المخصصة:</strong> ${dataUsage.settings} خيار
            </div>
        </div>
    `);
}

function calculateDataUsage() {
    let localStorageSize = 0;
    for (let key in localStorage) {
        if (localStorage.hasOwnProperty(key)) {
            localStorageSize += localStorage.getItem(key).length;
        }
    }

    return {
        localStorage: Math.round(localStorageSize / 1024),
        bookmarks: bookmarks.length,
        tasbihHistory: tasbihHistory.length,
        chatHistory: chatHistory.length,
        settings: Object.keys(appSettings).length
    };
}

function applySavedSettings() {
    // Apply theme
    document.documentElement.setAttribute('data-theme', currentTheme);
    const themeButton = document.getElementById('theme-toggle');
    if (currentTheme === 'dark') {
        themeButton.innerHTML = '☀️ الوضع النهاري';
    } else {
        themeButton.innerHTML = '🌙 الوضع الليلي';
    }

    // Apply language
    document.getElementById('language-select').value = currentLanguage;
    updateLanguageContent();

    // Apply notification settings
    updateNotificationButton();
    document.getElementById('reminder-time').value = notificationSettings.reminderTime;
    document.getElementById('sound-enabled').checked = notificationSettings.soundEnabled;
    document.getElementById('vibration-enabled').checked = notificationSettings.vibrationEnabled;

    // Apply prayer settings
    const prayerCheckboxes = document.querySelectorAll('.prayer-settings input[type="checkbox"]');
    prayerCheckboxes.forEach(checkbox => {
        const prayer = checkbox.dataset.prayer;
        checkbox.checked = notificationSettings.prayers[prayer];
    });

    // Apply advanced settings
    applyFontSettings();
    applyColorSettings();
    applyAnimationSettings();
    applyPerformanceSettings();

    // Apply settings to form elements
    document.getElementById('font-size').value = appSettings.fontSize;
    document.getElementById('font-family').value = appSettings.fontFamily;
    document.getElementById('primary-color').value = appSettings.primaryColor;
    document.getElementById('animation-speed').value = appSettings.animationSpeed;
    document.getElementById('auto-play-audio').checked = appSettings.autoPlayAudio;
    document.getElementById('audio-quality').value = appSettings.audioQuality;
    document.getElementById('notification-sound').checked = appSettings.notificationSound;
    document.getElementById('volume-control').value = appSettings.volume;
    document.getElementById('save-search-history').checked = appSettings.saveSearchHistory;
    document.getElementById('analytics-enabled').checked = appSettings.analyticsEnabled;
    document.getElementById('privacy-mode').checked = appSettings.privacyMode;
    document.getElementById('power-saving').checked = appSettings.powerSaving;
    document.getElementById('auto-update').checked = appSettings.autoUpdate;
    document.getElementById('cache-size').value = appSettings.cacheSize;

    updateCacheSizeDisplay();
}

// Network and Performance Functions
function updateOnlineStatus() {
    isOnline = navigator.onLine;
    const statusIndicator = document.getElementById('connection-status');
    const statusText = document.getElementById('status-text');

    if (statusIndicator) {
        if (isOnline) {
            statusIndicator.classList.remove('offline');
            statusIndicator.classList.add('online');
            if (statusText) statusText.textContent = 'متصل';
        } else {
            statusIndicator.classList.remove('online');
            statusIndicator.classList.add('offline');
            if (statusText) statusText.textContent = 'غير متصل';
        }
    }

    // Handle offline/online events
    if (isOnline) {
        // Sync offline data when back online
        syncOfflineData();
        showNotification('تم الاتصال بالإنترنت', 'جاري مزامنة البيانات...');
    } else {
        showNotification('انقطع الاتصال بالإنترنت', 'سيتم العمل في وضع الأوفلاين');
    }
}

function syncOfflineData() {
    // Sync any offline actions
    if (localStorage.getItem('offlineActions')) {
        const offlineActions = JSON.parse(localStorage.getItem('offlineActions'));
        // Process offline actions here
        localStorage.removeItem('offlineActions');
    }
}

function addConnectionStatusIndicator() {
    const header = document.querySelector('header');
    const statusDiv = document.createElement('div');
    statusDiv.id = 'connection-status';
    statusDiv.className = isOnline ? 'online' : 'offline';
    statusDiv.innerHTML = `
        <span id="status-text">${isOnline ? 'متصل' : 'غير متصل'}</span>
        <div class="status-indicator"></div>
    `;
    header.appendChild(statusDiv);
}

function optimizePerformance() {
    // Lazy loading for non-critical resources
    if ('IntersectionObserver' in window) {
        const lazyLoadObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const element = entry.target;
                    if (element.dataset.src) {
                        element.src = element.dataset.src;
                        element.removeAttribute('data-src');
                        lazyLoadObserver.unobserve(element);
                    }
                }
            });
        });

        // Observe images and iframes for lazy loading
        document.querySelectorAll('[data-src]').forEach(element => {
            lazyLoadObserver.observe(element);
        });
    }

    // Preload critical resources
    preloadCriticalResources();

    // Optimize images
    optimizeImages();

    // Setup memory management
    setupMemoryManagement();
}

function preloadCriticalResources() {
    const criticalResources = [
        '/hadiths.json',
        '/adhkar.json',
        '/duas.json'
    ];

    criticalResources.forEach(resource => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.href = resource;
        link.as = 'fetch';
        document.head.appendChild(link);
    });
}

function optimizeImages() {
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        if (img.loading !== 'lazy') {
            img.loading = 'lazy';
        }
    });
}

function setupMemoryManagement() {
    // Clean up memory periodically
    setInterval(() => {
        // Clear old cached data if cache is too large
        const cacheSize = calculateDataUsage().localStorage;
        if (cacheSize > 500) { // If more than 500KB
            clearOldCache();
        }
    }, 300000); // Every 5 minutes
}

function clearOldCache() {
    // Remove old cached API responses
    const cacheKeys = Object.keys(localStorage).filter(key =>
        key.includes('Cache') && Date.now() - (JSON.parse(localStorage.getItem(key + '_timestamp')) || 0) > 86400000 // 24 hours
    );

    cacheKeys.forEach(key => {
        localStorage.removeItem(key);
        localStorage.removeItem(key + '_timestamp');
    });
}

function handleOfflineActions(action, data) {
    if (!isOnline) {
        const offlineActions = JSON.parse(localStorage.getItem('offlineActions')) || [];
        offlineActions.push({
            action,
            data,
            timestamp: Date.now()
        });
        localStorage.setItem('offlineActions', JSON.stringify(offlineActions));
    }
}

function getCachedData(key) {
    const cached = localStorage.getItem(key);
    const timestamp = localStorage.getItem(key + '_timestamp');

    if (cached && timestamp) {
        const age = Date.now() - parseInt(timestamp);
        const maxAge = 3600000; // 1 hour

        if (age < maxAge) {
            return JSON.parse(cached);
        } else {
            // Data is too old, remove it
            localStorage.removeItem(key);
            localStorage.removeItem(key + '_timestamp');
        }
    }

    return null;
}

function setCachedData(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
    localStorage.setItem(key + '_timestamp', Date.now().toString());
}

function smartFetch(url, options = {}) {
    return new Promise((resolve, reject) => {
        // Try cache first if offline or if it's a non-critical request
        if (!isOnline || options.useCache) {
            const cachedData = getCachedData(url);
            if (cachedData) {
                resolve(cachedData);
                return;
            }
        }

        // Fetch from network
        fetch(url, options)
            .then(response => {
                if (response.ok) {
                    return response.json();
                }
                throw new Error('Network response was not ok');
            })
            .then(data => {
                // Cache the response
                setCachedData(url, data);
                resolve(data);
            })
            .catch(error => {
                // Try to get cached data if network fails
                const cachedData = getCachedData(url);
                if (cachedData) {
                    console.warn('Using cached data due to network error:', error);
                    resolve(cachedData);
                } else {
                    reject(error);
                }
            });
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('sw.js')
            .then(registration => {
                console.log('Service Worker registered successfully');
            })
            .catch(error => {
                console.error('Service Worker registration failed:', error);
            });
    }

    // Add connection status indicator
    addConnectionStatusIndicator();

    // Monitor online/offline status
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);

    // Apply saved settings first
    applySavedSettings();

    // Initialize performance optimizer
    if (window.performanceOptimizer) {
        window.performanceOptimizer.logPerformanceMetric('app_init', 'started');
    }

    // Optimize performance
    optimizePerformance();

    // Load data with smart caching
    loadAppData();

    // Setup update intervals based on settings
    setupUpdateIntervals();

    // Initialize push notifications if supported
    initializePushNotifications();

    // Initialize backup system
    initializeBackupSystem();

    // Initialize testing and monitoring
    initializeAppTesting();

    // Initialize error handling
    initializeErrorHandling();

    // Load performance optimizer script
    const performanceScript = document.createElement('script');
    performanceScript.src = 'performance-optimizer.js';
    performanceScript.onload = () => {
        console.log('Performance optimizer loaded successfully');
    };
    performanceScript.onerror = () => {
        console.warn('Could not load performance optimizer');
    };
    document.head.appendChild(performanceScript);

    // Load accessibility enhancements script
    const accessibilityScript = document.createElement('script');
    accessibilityScript.src = 'accessibility-enhancements.js';
    accessibilityScript.onload = () => {
        console.log('Accessibility enhancements loaded successfully');
    };
    accessibilityScript.onerror = () => {
        console.warn('Could not load accessibility enhancements');
    };
    document.head.appendChild(accessibilityScript);
});

// -------------------------
// Authentication UI + helpers
// -------------------------

function openAuthModal(mode = 'login') {
    // mode = 'login' or 'register'
    const container = document.getElementById('auth-modal-container');
    const modal = document.createElement('div');
    modal.className = 'modal auth-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeAuthModal()">&times;</span>
            <h3>${mode === 'login' ? 'تسجيل الدخول' : 'إنشاء حساب'}</h3>
            <div class="auth-form">
                <input id="auth-name" placeholder="الاسم" style="display:${mode === 'login' ? 'none' : 'block'}" />
                <input id="auth-email" placeholder="البريد الإلكتروني" />
                <input id="auth-password" type="password" placeholder="كلمة المرور" />
                <button id="auth-submit">${mode === 'login' ? 'دخول' : 'تسجيل'}</button>
                <p id="auth-message" style="color:var(--text-color);"></p>
                <p style="margin-top:.5rem;font-size:.9rem">${mode === 'login' ? "لا تملك حساباً؟ <a href='#' onclick=\"switchAuthMode('register')\">سجّل الآن</a>" : "هل لديك حساب؟ <a href='#' onclick=\"switchAuthMode('login')\">سجّل الدخول</a>"}</p>
            </div>
        </div>
    `;

    container.innerHTML = '';
    container.appendChild(modal);

    document.getElementById('auth-submit').addEventListener('click', async () => {
        const email = document.getElementById('auth-email').value.trim();
        const password = document.getElementById('auth-password').value;
        const name = document.getElementById('auth-name') ? document.getElementById('auth-name').value.trim() : '';
        const msgEl = document.getElementById('auth-message');
        msgEl.textContent = '';

        try {
            if (mode === 'login') {
                const res = await authLogin({ email, password });
                if (res && res.token) {
                    saveToken(res.token);
                    msgEl.textContent = 'تم تسجيل الدخول بنجاح';
                    closeAuthModal();
                } else {
                    msgEl.textContent = res.message || 'فشل تسجيل الدخول';
                }
            } else {
                const res = await authRegister({ name, email, password });
                if (res && res.user) {
                    msgEl.textContent = 'تم إنشاء الحساب، يمكنك تسجيل الدخول الآن.';
                    setTimeout(() => switchAuthMode('login'), 1200);
                } else {
                    msgEl.textContent = res.message || 'فشل التسجيل';
                }
            }
        } catch (err) {
            msgEl.textContent = err.message || 'خطأ ما';
        }
    });
}

function closeAuthModal() {
    const container = document.getElementById('auth-modal-container');
    container.innerHTML = '';
}

function switchAuthMode(mode) {
    openAuthModal(mode);
}

async function authRegister({ name, email, password }) {
    const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
    });
    return res.json();
}

async function authLogin({ email, password }) {
    const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    });
    return res.json();
}

function saveToken(token) {
    localStorage.setItem('rafiq_token', token);
}

function getToken() {
    return localStorage.getItem('rafiq_token');
}

// Helper to call protected endpoints with stored token
async function authFetch(url, options = {}) {
    options.headers = options.headers || {};
    options.headers['Content-Type'] = options.headers['Content-Type'] || 'application/json';
    const token = getToken();
    if (token) options.headers['Authorization'] = 'Bearer ' + token;
    const res = await fetch(url, options);
    if (res.status === 401) {
        // token invalid or expired - remove
        localStorage.removeItem('rafiq_token');
    }
    return res;
}

// Show user status in header and add logout
async function fetchCurrentUser() {
    try {
        const res = await authFetch('/api/auth/profile', { method: 'GET' });
        if (!res.ok) return null;
        const data = await res.json();
        return data.user;
    } catch (e) {
        return null;
    }
}

function showUserState(user) {
    const el = document.getElementById('user-status');
    const loginBtn = document.getElementById('login-btn');
    if (!el) return;
    if (user) {
        el.innerHTML = `
            <span style="margin-right:8px">${user.name || user.email}</span>
            <button onclick="logout()">خروج</button>
        `;
        if (loginBtn) loginBtn.style.display = 'none';
    } else {
        el.innerHTML = '';
        if (loginBtn) loginBtn.style.display = 'inline-block';
    }
}

function logout() {
    localStorage.removeItem('rafiq_token');
    showUserState(null);
}

// On load, try to fetch current user and update header
document.addEventListener('DOMContentLoaded', async () => {
    const user = await fetchCurrentUser();
    showUserState(user);
});

function loadAppData() {
    // Load prayer times (critical - try network first)
    fetchPrayerTimes();

    // Load Quran data (can use cache)
    loadSurahs();
    loadQuranData();

    // Load other data (can use cache)
    loadHijriDate();
    loadHadiths();
    loadDuas();
    getQiblaDirection();
    updateTasbihHistory();
}

function setupUpdateIntervals() {
    const interval = appSettings.powerSaving ? 120000 : 60000; // 2 minutes or 1 minute

    setInterval(() => {
        if (isOnline || !appSettings.powerSaving) {
            updateCountdown();
            checkReminders();
        }
    }, interval);
}

function initializePushNotifications() {
    if ('Notification' in window && 'serviceWorker' in navigator) {
        Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
                console.log('Push notifications enabled');
            }
        });
    }
}