const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const User = require('./models/User');

const router = express.Router();
const nodemailer = require('nodemailer');

async function requireAuth(req, res, next) {
  const h = req.headers.authorization;
  if (!h || !h.startsWith('Bearer ')) return res.status(401).json({ message: 'Authorization required' });
  try {
    const token = h.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'changeme');
    const user = await User.findById(decoded.userId).select('-password');
    if (!user) return res.status(401).json({ message: 'Invalid token' });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}

router.post('/register', [body('email').isEmail(), body('password').isLength({ min: 6 })], async (req, res) => {
  const v = validationResult(req);
  if (!v.isEmpty()) return res.status(400).json({ errors: v.array() });
  const { email, password, name } = req.body;
  try {
    if (await User.findOne({ email })) return res.status(409).json({ message: 'Email already exists' });
    const hashed = await bcrypt.hash(password, 10);
    const u = new User({ email, password: hashed, name });
    await u.save();
    // send verification email if possible
    const transporter = getTransporter();
    if (transporter) {
      const token = jwt.sign({ userId: u._id }, process.env.JWT_SECRET || 'changeme', { expiresIn: '7d' });
      const verifyUrl = `${process.env.FRONTEND_URL || 'http://localhost:5000'}/verify?token=${token}`;
      transporter.sendMail({
        from: process.env.FROM_EMAIL || process.env.EMAIL_USER,
        to: u.email,
        subject: 'Please verify your email',
        text: `Verify your email by clicking: ${verifyUrl}`
      }).catch(err => console.error('Mail send error', err));
    }
    return res.status(201).json({ message: 'Registered', user: { email: u.email, name: u.name } });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
});

router.post('/login', [body('email').isEmail(), body('password').exists()], async (req, res) => {
  const v = validationResult(req);
  if (!v.isEmpty()) return res.status(400).json({ errors: v.array() });
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });
    if (!(await bcrypt.compare(password, user.password))) return res.status(401).json({ message: 'Invalid credentials' });
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET || 'changeme', { expiresIn: '1d' });
    return res.json({ token, user: { email: user.email, name: user.name } });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
});

router.get('/profile', requireAuth, (req, res) => res.json({ user: req.user }));

// Email transporter (simple config via env)
function getTransporter() {
  if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
    return nodemailer.createTransport({
      host: process.env.EMAIL_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.EMAIL_PORT || '587'),
      secure: process.env.EMAIL_SECURE === 'true',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });
  }
  return null;
}

// Send verification email
router.post('/forgot', [body('email').isEmail()], async (req, res) => {
  const v = validationResult(req);
  if (!v.isEmpty()) return res.status(400).json({ errors: v.array() });
  const { email } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(200).json({ message: 'If that email is registered, a reset link will be sent.' });
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET || 'changeme', { expiresIn: '1h' });
    const transporter = getTransporter();
    if (transporter) {
      const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:5000'}/reset.html?token=${token}`;
      await transporter.sendMail({
        from: process.env.FROM_EMAIL || process.env.EMAIL_USER,
        to: user.email,
        subject: 'Password reset',
        text: `Use this link to reset your password: ${resetUrl}`
      });
    }
    return res.json({ message: 'If that email is registered, a reset link will be sent.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
});

router.post('/reset', [body('token').exists(), body('password').isLength({ min: 6 })], async (req, res) => {
  const v = validationResult(req);
  if (!v.isEmpty()) return res.status(400).json({ errors: v.array() });
  const { token, password } = req.body;
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'changeme');
    const user = await User.findById(decoded.userId);
    if (!user) return res.status(400).json({ message: 'Invalid token' });
    user.password = await bcrypt.hash(password, 10);
    await user.save();
    return res.json({ message: 'Password reset successful' });
  } catch (err) {
    console.error(err);
    return res.status(400).json({ message: 'Invalid or expired token' });
  }
});

// Email verification link
router.get('/verify/:token', async (req, res) => {
  const { token } = req.params;
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'changeme');
    const user = await User.findById(decoded.userId);
    if (!user) return res.status(400).send('Invalid token');
    user.verified = true;
    await user.save();
    return res.send('Email verified. You can now login.');
  } catch (err) {
    console.error(err);
    return res.status(400).send('Invalid or expired token');
  }
});

module.exports = router;